using System;
using System.Net;
using System.Text;
using UnityEngine;
using System.Net.Sockets;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine.UI;

public class UDPServer : MonoBehaviour
{
    private UdpClient server;
    private IPEndPoint clientEndPoint;
    public MapScene2 _map;
    public Altitude _altitude;

    [Header("Network Config.")]
    public int wifiPort = 8080;
    // public string magicLeapIP = "169.234.14.30";

    [Header("Receiver Parameters:")]
    public int goalReached = 0;
    public Vector3 playerPositionLLA;

    [Header("Sending Parameters:")]
    public double targetLat;    // send
    public double targetLon;    // send
    public double targetAlt;    // send
    
    private Vector3 targetLLA;  // Latitude, longitude, and altitude, in a geographic coordinate system

    private double lastTargetLat;
    private double lastTargetLon;
    private double lastTargetAlt;
    [SerializeField] private TextMeshProUGUI wifiDebugText;
    [SerializeField] private TextMeshProUGUI firefigterPositionDebugText;

    public Button sendMsgBtn;
    private string serverMessage_str;
    private string wifiDebugMssg;
    private bool isFirstMessageSent;
    private bool isMessageSentCorrectly;


    void Awake() 
    {
        Button btn = sendMsgBtn.GetComponent<Button>();
		btn.onClick.AddListener(btnOnClick);

        try 
        {
            server = new UdpClient(wifiPort);
            clientEndPoint = new IPEndPoint(IPAddress.Any, 0);
            // clientEndPoint = new IPEndPoint(IPAddress.Parse(magicLeapIP), 8080);
            print("Created UDP server!");
        }
        catch (SocketException e) 
        {
            Debug.LogError("Failed to create UDP server: " + e.Message);
            return;
        }

        _map = FindObjectOfType<MapScene2>();
        if (_map == null) 
        {
            Debug.LogError("Map script not found or not assigned to any object.");
        }

        _altitude = FindObjectOfType<Altitude>();
        if (_altitude == null) 
        {
            Debug.LogError("Altitude script not found or not assigned to any object.");
        }

        // Start receiving messages
        server.BeginReceive(ReceiveCallback, null);
    }

    void FixedUpdate() 
    {
        // Redundant but is for purpose of visualization on Unity Editor
        targetLat = _map.targetLatitude;
        targetLon = _map.targetLongitude;
        targetAlt = _altitude.targetAltitude;

        string targetLat_str = targetLat.ToString();
        string targetLon_str = targetLon.ToString();
        string targetAlt_str = targetAlt.ToString();
        serverMessage_str = targetLat_str + ", " + targetLon_str + ", " + targetAlt_str;

        // Update values to check if the target has changed
        lastTargetLat = targetLat;
        lastTargetLon = targetLon;
        lastTargetAlt = targetAlt;

        if (!isFirstMessageSent)
        {
            wifiDebugMssg = "Lat: "+targetLat.ToString()+"\nLon: "+targetLon.ToString()+"\nAlt: "+targetAlt.ToString();
        }
        if(isFirstMessageSent && isMessageSentCorrectly)
        {
            wifiDebugMssg = "Lat: "+targetLat.ToString()+"\nLon: "+targetLon.ToString()+"\nAlt: "+targetAlt.ToString()+"\nStatus: ok";
        }
        else if(isFirstMessageSent && !isMessageSentCorrectly)
        {
            wifiDebugMssg = "Lat: "+targetLat.ToString()+"\nLon: "+targetLon.ToString()+"\nAlt: "+targetAlt.ToString()+"\nStatus: failed to send";
        }
        wifiDebugText.text = wifiDebugMssg;
    }

    private void ReceiveCallback(IAsyncResult ar) 
    {
        byte[] data = server.EndReceive(ar, ref clientEndPoint);
        string clientMessage = Encoding.ASCII.GetString(data);

        Debug.Log("client message received as: " + clientMessage);

        // Assign variables:
        Regex sc = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?");
        var matches_sc = sc.Matches(clientMessage);
        Debug.Log("client message num of matches: " + matches_sc.Count);
        if (matches_sc.Count == 3)
        {
            playerPositionLLA = new Vector3(float.Parse(matches_sc[0].Value), float.Parse(matches_sc[1].Value), float.Parse(matches_sc[2].Value));

            string msgReceived = "Lat: " + playerPositionLLA.x.ToString() + "\nLon: " + playerPositionLLA.y.ToString() + "\nAlt: " + playerPositionLLA.z.ToString();
            firefigterPositionDebugText.text = msgReceived;
        }

        // Continue receiving messages
        server.BeginReceive(ReceiveCallback, null);
    }

    private void SendMessage(string serverMessage) 
    {
        byte[] data = Encoding.ASCII.GetBytes(serverMessage);
        try 
        {
            server.Send(data, data.Length, clientEndPoint);
            Debug.Log("Server sent his message - should be received by client");
            Debug.Log("Message sent: " + serverMessage);

            isMessageSentCorrectly = true;
            isFirstMessageSent = true;
        }
        catch (SocketException e) 
        {
            isMessageSentCorrectly = false;
            isFirstMessageSent = true;

            Debug.LogWarning($"SendMessage failed: {e}");
        }

        // Continue receiving messages
        server.BeginReceive(ReceiveCallback, null);
    }

    void btnOnClick()
    {
		SendMessage(serverMessage_str);
	}

    private void OnDisable() 
    {
        if (server != null) 
        {
            server.Close();
        }
    }

    private void OnDestroy() 
    {
        if (server != null) 
        {
            server.Close();
        }
    }
}