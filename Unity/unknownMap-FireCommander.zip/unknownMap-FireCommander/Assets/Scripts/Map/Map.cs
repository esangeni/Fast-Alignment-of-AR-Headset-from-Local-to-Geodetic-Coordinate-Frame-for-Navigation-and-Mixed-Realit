using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System;
using TMPro;

public class Map : MonoBehaviour
{
    [Header("Google Map Settings")]
    private string apiKey = "AIzaSyCCTlEkssUhFEDC-_hUE3-5sJfT2EWSw_M";
    public double lat = 33.643211255612904;
    private double latLast = 33.643211255612904;
    public double lon = -117.83980115803249;
    private double lonLast = -117.83980115803249;
    [Range(12, 20)] public int zoom = 12;
    private int zoomLast = 12;
    public enum resolution {high = 1, low = 2};
    public resolution mapResolution = resolution.high;
    private resolution mapResolutionLast = resolution.high;
    public enum type {roadmap, satellite, gybrid, terrain};
    public type mapType = type.roadmap;
    private type mapTypeLast = type.roadmap;
    private string url = "";

    [Header("Map Dimensions")]
    public int mapWidth = 2160; //600 640 1440 2160 -- 4320x4320 pixels (if scale 2)
    public int mapHeight = 2160;
    public Camera camera;

    // Lower left (0,0)
    // Top rigth (3840x2160) (widthxheigth)
    // Centered Map image:
    //  - Lower left: 840x0 (3840/2-1080 := width x heigth min)
    //  - Top rigth: 3000x2160 (3840/2+1080 := width x heigth max)

    [Header("Internal State")]
    private bool mapIsLoading = false;
    private Rect rect;
    private string apiKeyLast;
    public bool updateMap = true;
    public bool updatePlayerPosition = false;
    [SerializeField] private float updateFrequency = 0.2f; // Seconds between updates
    private float lastUpdateTime = 0f;

    [Header("UI Components")]
    [SerializeField] private Image redDotImage; // Assign this via the Inspector – should be a child of the map RawImage
    [SerializeField] private Image blueDotImage; // Assign this via the Inspector – should be a child of the map RawImage
    [SerializeField] private TextMeshProUGUI latlonText;
    [SerializeField] private TMP_Dropdown mapTypeDropdown;
    [SerializeField] private TMP_Dropdown resolutionDropdown;
    [SerializeField] private RectTransform mapRectTransform;

    [Header("Target Position:")]
    public double targetLat;
    public double targetLon;

    void Start()
    {
        StartCoroutine(GetGoogleMap());
        rect = gameObject.GetComponent<RawImage>().rectTransform.rect;
        mapWidth = (int)Math.Round(rect.width);
        mapHeight = (int)Math.Round(rect.height);
        Debug.Log("Map width: " + mapWidth + ", heigth: " + mapHeight);

        // Dropdown listeners:
        mapTypeDropdown.onValueChanged.AddListener(delegate {
            DropdownValueChanged(mapTypeDropdown); // This should work as expected now
        });

        resolutionDropdown.onValueChanged.AddListener(delegate {
            ResolutionDropdownValueChanged(resolutionDropdown);
        });

        redDotImage.gameObject.SetActive(false);
        blueDotImage.gameObject.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(1)) // Check if right mouse button was clicked
        {
            Vector2 clickPosition = Input.mousePosition;
            Debug.Log("Click position: " + clickPosition);

            // Calculate lat and lon based on the local click position
            // Vector2 geoCoords = CalculateLatLon(clickPosition);
            // Debug.Log($"Clicked location - Lat: {geoCoords.x.ToString("F6")}, Lon: {geoCoords.y.ToString("F6")}");


            double[] geoCoords = GetLonLatOnClick(lat, lon, clickPosition);


            Debug.Log($"Clicked location - Lat: {geoCoords[0].ToString("F6")}, Lon: {geoCoords[1].ToString("F6")}");

            targetLat = geoCoords[0];
            targetLon = geoCoords[1];

            if (latlonText != null) // Adding null check
                latlonText.text = "("+ targetLat.ToString() +", "+ targetLon.ToString() +")";

            // // Convert click position into local coordinates of the RawImage
            // RectTransformUtility.ScreenPointToLocalPointInRectangle(gameObject.GetComponent<RawImage>().rectTransform, new Vector2((float)clickPosition.x, (float)clickPosition.y), null, out Vector2 localClickPosition);

            // // Proceed if the click is within the bounds of the RawImage
            // if(gameObject.GetComponent<RawImage>().rectTransform.rect.Contains(localClickPosition))
            // {
            //     // Calculate lat and lon based on the local click position
            //     Vector2 geoCoords = CalculateLatLon(localClickPosition);
            //     // Debug.Log($"Clicked location - Lat: {geoCoords.x}, Lon: {geoCoords.y}");

            //     targetLat = geoCoords.x;
            //     targetLon = geoCoords.y;

            //     if (latlonText != null) // Adding null check
            //         latlonText.text = "("+ targetLat.ToString() +", "+ targetLon.ToString() +")";
            // }
            // else {
            //     Debug.Log("NO.");
            // }
        }

        HandleArrowKeyNavigation();

        HandleZoom();
        
        if(updateMap && (apiKeyLast != apiKey || !Mathf.Approximately((float)latLast, (float)lat) || !Mathf.Approximately((float)lonLast, (float)lon) || zoomLast != zoom || mapResolutionLast != mapResolution || mapTypeLast != mapType))
        {
            rect = gameObject.GetComponent<RawImage>().rectTransform.rect;
            mapWidth = (int)Math.Round(rect.width);
            mapHeight = (int)Math.Round(rect.height);
            StartCoroutine(GetGoogleMap());
            updateMap = false;
            updatePlayerPosition = false;
        }
    }

    private IEnumerator GetGoogleMap()
    {
        url = "https://maps.googleapis.com/maps/api/staticmap?center=" + lat + "," + lon + "&zoom=" + zoom + "&size=" + mapWidth + "x" + mapHeight + "&scale=" + mapResolution + "&maptype=" + mapType + "&key=" + apiKey;
        mapIsLoading = true;
        if(mapIsLoading)
        {
            redDotImage.gameObject.SetActive(false);
            updatePlayerPosition = false;
        }

        UnityWebRequest www = UnityWebRequestTexture.GetTexture(url);
        yield return www.SendWebRequest();

        if(www.result != UnityWebRequest.Result.Success)
        {
            Debug.LogWarning("WWW ERROR: " + www.error);
        }
        else
        {
            mapIsLoading = false;
            gameObject.GetComponent<RawImage>().texture = ((DownloadHandlerTexture)www.downloadHandler).texture;

            apiKeyLast = apiKey;
            latLast = lat;
            lonLast = lon;
            zoomLast = zoom;
            mapResolutionLast = mapResolution;
            mapTypeLast = mapType;
            updateMap = true;
            updatePlayerPosition = true;
        }
    }

    // private Vector2 CalculateLatLon(Vector2 localClickPosition)
    // {
    //     float x = localClickPosition.x;
    //     float y = localClickPosition.y;

    //     Debug.Log("Click position CalculateLatLon: " + x + ", " + y);

    //     // Calculate screen center based on actual screen dimensions
    //     Vector2 screenCenter = new Vector2(Screen.width / 2f, Screen.height / 2f);

    //     // redDotImage.transform.position = new Vector2(x + screenCenter.x, y + screenCenter.y);
    //     redDotImage.transform.position = new Vector2((float)x, (float)y);
    //     redDotImage.gameObject.SetActive(true);

    //     double pxPerDegree = mapWidth / 360.0f * Mathf.Pow(2, zoom - 1); // Scale factor

    //     // Early computations in double for precision
    //     double lonOffset = x / pxPerDegree;
    //     double calculatedLon = lon + lonOffset;

    //     double latOffset = y / pxPerDegree;
    //     double calculatedLat = lat + latOffset;

    //     // Convert back to float only when returning or interacting with Unity components
    //     return new Vector2(ToFloat(calculatedLat), ToFloat(calculatedLon));
    // }


    private Vector2 CalculateLatLon(Vector2 clickPosition)
    {
        // Convert screen click to local map position
        Vector2 localClickPosition;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(mapRectTransform, clickPosition, camera, out localClickPosition);
        Debug.Log("localClickPosition: " + localClickPosition);
        
        // Now, localClickPosition is relative to the center of the map, where (0,0) is the center of the "Map" object.
        
        double scale = 1 << zoom; // Equivalent to Math.Pow(2, zoom)
        double resolution = 360 / (256 * scale); // The world map is 256 pixels wide at zoom level 0.
        double centerPixelX = ((lon + 180.0) / 360.0) * (256 * scale);
        double centerPixelY = ((Math.Log(Math.Tan((Math.PI / 4) + (Math.PI / 2) * (lat / 180.0))) + Math.PI) / (2 * Math.PI)) * (256 * scale);
        Vector2 mapCenterScreenPos = mapRectTransform.position;

        // Vector2 deltaScreenPos = new Vector2(mapCenterScreenPos.x, mapCenterScreenPos.y) + new Vector2(-3840/2 + clickPosition.x, -2160/2 + clickPosition.y);
        double pixelX = centerPixelX + localClickPosition.x;
        double pixelY = centerPixelY + localClickPosition.y;

        double newLon = (pixelX / (256 * scale)) * 360.0 - 180.0;
        double newLatRad = (2 * Math.Atan(Math.Exp((pixelY / (256 * scale)) * 2 * Math.PI - Math.PI)) - Math.PI / 2);
        double newLat = newLatRad * (180.0 / Math.PI);

        return new Vector2((float)newLat, (float)newLon);
    }

    //------------------------------------------------------

    private double[] GetLonLatOnClick(double centerLat, double centerLon, Vector2 clickPosition)
    {
        // Convert screen click to local map position
        Vector2 localClickPosition;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(mapRectTransform, clickPosition, camera, out localClickPosition);
        Debug.Log("localClickPosition: " + localClickPosition);

        double distanceToTarget = Math.Sqrt(Math.Pow(localClickPosition.x/2, 2) + Math.Pow(localClickPosition.y/2, 2)); // Hypotenuse from two sides.
        double topRightBearing = Math.Atan((localClickPosition.x) / (localClickPosition.y)); // Top right conrer Bearing [rad]

        double[] latLonTarget = GetPointLonLat(centerLat, centerLon, distanceToTarget, topRightBearing);
        
        return new double[] {latLonTarget[0], latLonTarget[1]}; // Lat, Lon
    }

    private double[] GetRecMinMaxLonLat(double centerLon, double centerLat, double width, double height)
    {
        double distance = Math.Sqrt(Math.Pow(height / 2.0, 2) + Math.Pow(width / 2.0, 2)); // Hypotenuse from two sides.
        double topRightBearing = Math.Atan((width / 2.0) / (height / 2.0)); // Top right conrer Bearing [rad]
        double bottomLeftBearing = Math.PI + topRightBearing; // Bottom left conrer Bearing [rad] := Top right conrer + 180 [deg]
        double[] topRight = GetPointLonLat(centerLat, centerLon, distance, topRightBearing);
        double[] bottomLeft = GetPointLonLat(centerLat, centerLon, distance, bottomLeftBearing);
        
        return new double[] {bottomLeft[0], bottomLeft[1], topRight[0], topRight[1]};
    }

    private double[] GetPointLonLat(double startLatDeg, double startLonDeg, double distance, double bearingRad)
    {
        double earthRadius = 6378100.0; // [m]
        double startLatRad = startLatDeg * (Math.PI / 180); // [rad]
        double startLonRad = startLonDeg * (Math.PI / 180); // [rad]
        double targetLatRad = Math.Asin(Math.Sin(startLatRad) * Math.Cos(distance/earthRadius) + Math.Cos(startLatRad) * Math.Sin(distance / earthRadius) * Math.Cos(bearingRad)); // [rad]
        double targetLonRad = startLonRad + Math.Atan2(Math.Sin(bearingRad) * Math.Sin(distance / earthRadius) * Math.Cos(startLatRad), Math.Cos(distance/earthRadius) - Math.Sin(startLatRad) * Math.Sin(targetLatRad)); // [rad]

        return new double[] {targetLatRad * (180 / Math.PI), targetLonRad * (180 / Math.PI)}; // Lat, Lon: [deg]
    }

















    //------------------------------------------------------

    private void HandleZoom()
    {
        // Get mouse scroll wheel input
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            // Modify the zoom level based on scroll direction
            zoom += scroll > 0 ? 1 : -1;

            // Ensure zoom value stays within its defined range
            zoom = Mathf.Clamp(zoom, 12, 20);

            // Request a map update
            StartCoroutine(GetGoogleMap());

            // Force an update
            updateMap = true; 
        }
    }

    private void HandleArrowKeyNavigation()
    {
        // if (mapIsLoading || Time.time - lastUpdateTime < updateFrequency)
        //     return;

        double movementFactor = 1 / Math.Log(22 - zoom, 2) * 0.00005;
        updateMap = false;

        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            lat += movementFactor; // Move North
            updateMap = true;
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            lat -= movementFactor; // Move South
            updateMap = true;
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            lon += movementFactor; // Move East
            updateMap = true;
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            lon -= movementFactor; // Move West
            updateMap = true;
        }

        if (updateMap)
        {
            lastUpdateTime = Time.time;
            StartCoroutine(GetGoogleMap());
        }
    }

    private float ToFloat(double value)
    {
        return (float)value;
    }

    private void DropdownValueChanged(TMP_Dropdown change)
    {
        switch (change.value)
        {
            case 0:
                mapType = type.roadmap;
                break;
            case 1:
                mapType = type.satellite;
                break;
            case 2:
                mapType = type.gybrid;
                break;
            case 3:
                mapType = type.terrain;
                break;
        }

        // Since the map type has changed, request a map update
        StartCoroutine(GetGoogleMap());
    }

    private void ResolutionDropdownValueChanged(TMP_Dropdown change)
    {
        switch (change.value)
        {
            case 0:
                mapResolution = resolution.high; 
                break;
            case 1:
                mapResolution = resolution.low;
                break;
        }

        // Request a map update with the new resolution
        StartCoroutine(GetGoogleMap());
    }



    // Player functions
    public Vector2 GeographicToCanvasPosition(double latitude, double longitude)
    {
        // Calculate pixel per degree based on zoom level and map size
        double pixelsPerDegreeX = mapWidth / 360.0 * Mathf.Pow(2, zoom-1.3f);
        double pixelsPerDegreeY = mapWidth / 360.0 * Mathf.Pow(2, zoom-1.3f);

        double mercatorScale = 1 / Math.Cos(latitude * Mathf.Deg2Rad);

        // Delta in degrees from map center to target position
        double deltaLatitude = latitude - lat;
        double deltaLongitude = longitude - lon; 

        // Convert deltas to pixels
        double offsetY = deltaLatitude * pixelsPerDegreeY * mercatorScale;
        double offsetX = deltaLongitude * pixelsPerDegreeX;

        // Convert pixels offset to local position within the RectTransform
        Vector2 rectPosition = ConvertPixelsToLocalPosition(offsetX, offsetY);

        Debug.Log(rectPosition);

        return rectPosition;
    }

    private Vector2 ConvertPixelsToLocalPosition(double offsetX, double offsetY)
    {
        // Assuming mapRectTransform.pivot is at (.5, .5)
        float localPosX = (float) offsetX;
        float localPosY = (float) offsetY;

        // Adjust based on the actual anchoring and pivot settings
        // E.g., localPosX += mapRectTransform.rect.width * (mapRectTransform.pivot.x - 0.5f);

        return new Vector2(localPosX, localPosY);
    }
}