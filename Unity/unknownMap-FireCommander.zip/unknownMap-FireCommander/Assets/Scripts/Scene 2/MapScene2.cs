using System.Collections;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using System;
using TMPro;

public class MapScene2 : MonoBehaviour
{
    [SerializeField] private RawImage mapImage;
    private string apiKey = "AIzaSyCCTlEkssUhFEDC-_hUE3-5sJfT2EWSw_M"; // Be sure to replace this with your actual API key
    private int mapWidth = 640; // match this to your RawImage width
    private int mapHeight = 640; // match this to your RawImage height

    [Header("Parameters:")]
    public double centerLatitude;   // center latitude [deg] of the map
    public double centerLongitude;  // center longitude [deg] of the map

    public int zoomLevel = 20;      // zoom level on the map

    public enum resolution {low = 1, high = 2};
    public resolution mapResolution = resolution.high;

    public enum type {satellite, roadmap, gybrid, terrain};
    public type mapType = type.satellite;

    public double targetLatitude;   // target longitude [deg] of the map    
    public double targetLongitude;  // target longitude [deg] of the map
    public Vector2 targetXYPosition;   // target longitude [deg] of the map

    public bool updateMap = false;
    public bool updatePlayerPosition = false;

    [Header("UI Components:")]
    [SerializeField] private TMP_Dropdown mapTypeDropdown;
    [SerializeField] private TMP_Dropdown resolutionDropdown;
    [SerializeField] private TextMeshProUGUI latlonText;
    [SerializeField] private Image redDotImage;
    
    // URL template
    private string baseUrl = "https://maps.googleapis.com/maps/api/staticmap?";


    private bool isDragging = false;
    private Vector2 lastMousePosition;


    void Start()
    {
        redDotImage.gameObject.SetActive(false);

        // Dropdown listeners:
        mapTypeDropdown.onValueChanged.AddListener(delegate {
            DropdownValueChanged(mapTypeDropdown); // This should work as expected now
        });

        resolutionDropdown.onValueChanged.AddListener(delegate {
            ResolutionDropdownValueChanged(resolutionDropdown);
        });

        // Load Initial Map:
        LoadMap(centerLatitude, centerLongitude);
    }

    void Update()
    {
        if (updateMap)
        {
            Debug.Log($"Map center Lat: ({centerLatitude.ToString("F6")}, {centerLongitude.ToString("F6")})");
            LoadMap(centerLatitude, centerLongitude);
            updateMap = false;
            // redDotImage.gameObject.SetActive(false);
        }

        // Right click - Target Position Selection
        if (Input.GetMouseButtonDown(1) && isMouseOverMap()) 
        {
            Vector2 mousePos = Input.mousePosition;

            double[] targetLatLon = ConvertScreenCoordsWithMercantToLatLong(mousePos);
            targetLatitude = targetLatLon[0];
            targetLongitude = targetLatLon[1];
            Debug.Log($"Mercant Lat: {targetLatitude.ToString("F6")}, Lon: {targetLongitude.ToString("F6")}");
            if (latlonText != null) // Adding null check
                latlonText.text = "("+ targetLatitude.ToString("F6") +", "+ targetLongitude.ToString("F6") +")";

            targetXYPosition = mousePos;
            
            redDotImage.gameObject.SetActive(true);
            redDotImage.transform.position = new Vector2(targetXYPosition.x, targetXYPosition.y);
        }

        HandleZoom();

        if(isDragging)
        {
            redDotImage.gameObject.SetActive(false);
        }
    }

    void LateUpdate()
    {
        // Handle dragging:
        if (Input.GetMouseButtonDown(0) && isMouseOverMap()) // Left mouse button pressed
        {
            isDragging = true;
            lastMousePosition = Input.mousePosition; // Capture the starting point
        }
        else if (Input.GetMouseButtonUp(0)) // Left mouse button released
        {
            isDragging = false;
            // updateMap = true; // Signal to update the map

            if (isMouseOverMap()) // Also check here to update the map only if the mouse was released over the map
            {
                updateMap = true; // Signal to update the map
            }
        }

        if (isDragging && isMouseOverMap())
        {
            Vector2 mouseDelta = (Vector2)Input.mousePosition - lastMousePosition;
            HandleMapDrag(mouseDelta);
            lastMousePosition = Input.mousePosition; // Update the last position for the next frame
        }

        if(Input.GetMouseButtonUp(0))
        {
            updatePlayerPosition = true; // Consider updating the player position after dragging.
        }
    }

    private void LoadMap(double latitude, double longitude)
    {
        string url = $"{baseUrl}center={latitude},{longitude}&zoom={zoomLevel}&size={mapWidth}x{mapHeight}&scale={mapResolution}&maptype={mapType}&key={apiKey}";
        StartCoroutine(GetStaticMap(url));
    }

    private IEnumerator GetStaticMap(string url)
    {
        UnityWebRequest mapRequest = UnityWebRequestTexture.GetTexture(url);
        yield return mapRequest.SendWebRequest();

        if (mapRequest.result != UnityWebRequest.Result.Success)
        {
            Debug.LogError("Map request error: " + mapRequest.error);
        }
        else
        {
            Texture2D tex = ((DownloadHandlerTexture)mapRequest.downloadHandler).texture;
            mapImage.texture = tex;
        }
    }

    private double[] ConvertScreenCoordsWithMercantToLatLong(Vector2 screenCoords)
    {
        Debug.Log("Screen Coords: " + screenCoords);

        // Translate screen coordinates to local position within the map image
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(mapImage.rectTransform, screenCoords, null, out Vector2 localPoint)) {
            return new double[] { 0, 0 };
        }
        Debug.Log("Local Map Coords: " + localPoint);

        double mapScale = 256 * Math.Pow(2, zoomLevel);
        double pixelX = localPoint.x + (mapWidth / 2);
        double pixelY = localPoint.y + (mapHeight / 2);

        double pixelOffsetX = pixelX - (mapWidth / 2);
        double pixelOffsetY = pixelY - (mapHeight / 2);
        Debug.Log("Pixel Offset Y: " + pixelOffsetY);

        // Calculate longitude
        double lonDegPerPixel = 360.0 / mapScale;
        double longitude = centerLongitude + (pixelOffsetX * lonDegPerPixel);

        // Calculate latitude
        double latitude = centerLatitude + pixelOffsetY/Math.Pow(2, zoomLevel);
        
        return new double[] {latitude, longitude};
    }

    private void DropdownValueChanged(TMP_Dropdown change)
    {
        switch (change.value)
        {
            case 0:
                mapType = type.satellite;
                updateMap = true;
                updatePlayerPosition = true;
                break;
            case 1:
                mapType = type.roadmap;
                updateMap = true;
                updatePlayerPosition = true;
                break;
            case 2:
                mapType = type.gybrid;
                updateMap = true;
                updatePlayerPosition = true;
                break;
            case 3:
                mapType = type.terrain;
                updateMap = true;
                updatePlayerPosition = true;
                break;
        }
    }

    private void ResolutionDropdownValueChanged(TMP_Dropdown change)
    {
        switch (change.value)
        {
            case 0:
                mapResolution = resolution.high;
                updateMap = true;
                updatePlayerPosition = true;
                break;
            case 1:
                mapResolution = resolution.low;
                updateMap = true;
                updatePlayerPosition = true;
                break;
        }
    }

    private void HandleZoom()
    {
        // Get mouse scroll wheel input
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            // Modify the zoom level based on scroll direction
            zoomLevel += scroll > 0 ? 1 : -1;

            // Ensure zoom value stays within its defined range
            zoomLevel = Mathf.Clamp(zoomLevel, 17, 20);

            // Force an update
            updateMap = true;
            updatePlayerPosition = true;
        }
    }

    private float CalculateMovementSensitivity() 
    {
        float movementSensitivityBase = 0.00025f; // Base sensitivity, adjust as needed
        return movementSensitivityBase / Mathf.Pow(2, (20 - zoomLevel));
    }

    private void HandleMapDrag(Vector2 mouseDelta)
    {
        float adjustmentFactor = Mathf.Pow(2, 20 - zoomLevel);

        float sensitivity = CalculateMovementSensitivity() * 10f * adjustmentFactor; // Enhanced adjustment based on zoom level

        double deltaLongitude = mouseDelta.x * sensitivity / mapWidth;
        double deltaLatitude = -mouseDelta.y * sensitivity / mapHeight; // Invert y-axis movement

        centerLongitude -= deltaLongitude;
        centerLatitude += deltaLatitude;

        centerLongitude = NormalizeLongitude(centerLongitude);
        centerLatitude = ClampLatitude(centerLatitude);
    }

    private double NormalizeLongitude(double longitude)
    {
        return (longitude + 180.0) % 360.0 - 180.0; // Normalize to -180 to 180
    }

    private double ClampLatitude(double latitude)
    {
        return Mathf.Clamp((float)latitude, -85f, 85f); // Avoid poles
    }

    public Vector2 GeographicToMapPosition(double latitude, double longitude)
    {
        // Delta in degrees from map center to target position
        double deltaLatitude = latitude - centerLatitude;
        double deltaLongitude = longitude - centerLongitude;

        // Inverse from deltaLat to deltaY:
        // double latitude = centerLatitude + pixelOffsetY/Math.Pow(2, zoomLevel);
        double pixelOffsetY = deltaLatitude*Math.Pow(2, zoomLevel);


        // Inverse from deltaLon to deltaX:
        double mapScale = 256 * Math.Pow(2, zoomLevel);
        double lonDegPerPixel = 360.0 / mapScale;
        // double longitude = centerLongitude + (pixelOffsetX * lonDegPerPixel);
        double pixelOffsetX = deltaLongitude/lonDegPerPixel;

        Debug.Log("Offset LL Player Position: (" + deltaLatitude + ", " + deltaLongitude + ")");
        Debug.Log("Offset YX Player Position: (" + pixelOffsetY + ", " + pixelOffsetX + ")");


        return new Vector2((float)pixelOffsetX, (float)pixelOffsetY);
    }

    private bool isMouseOverMap()
    {
        return RectTransformUtility.RectangleContainsScreenPoint(mapImage.rectTransform, Input.mousePosition, null);
    }
}

public static class MathUtils
{
    public static double Deg2Rad(double degrees)
    {
        return degrees * Math.PI / 180.0;
    }
    
    public static double Rad2Deg(double radians)
    {
        return radians * 180.0 / Math.PI;
    }
}