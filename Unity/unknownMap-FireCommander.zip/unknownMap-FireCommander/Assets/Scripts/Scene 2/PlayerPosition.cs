using UnityEngine;
using System;
using UnityEngine.UI;
using TMPro;

public class PlayerPosition : MonoBehaviour
{
    // Static initial position
    private double playerLatitude = 33.643211255612904; 
    private double playerLongitude = -117.83980115803249;

    public MapScene2 mapScript;
    public UDPServer udpServer; 
    [SerializeField] private TextMeshProUGUI firefigterPositionDebugText;

    void Start()
    {
        string msgReceived = "Lat: " + playerLatitude.ToString() + "\nLon: " + playerLongitude.ToString() + "\nAlt: " + 0;
        firefigterPositionDebugText.text = msgReceived;

        if (mapScript == null)
        {
            Debug.LogError("Map script reference not assigned.");
            return;
        }
        if (udpServer == null)
        {
            Debug.LogError("udpServer script reference not assigned.");
            return;
        }

        UpdatePositionOnMap(playerLatitude, playerLongitude);
    }

    void Update()
    {
        // if(mapScript.updatePlayerPosition)
        // {       
        //     Debug.LogWarning("Update Player Position");
        //     UpdatePositionOnMap(playerLatitude, playerLongitude);
        //     // UpdatePositionOnMap(udpServer.playerPositionLLA.x, udpServer.playerPositionLLA.y); // lat, lon
        //     mapScript.updatePlayerPosition = false;
        // }

        UpdatePositionOnMap(udpServer.playerPositionLLA.x, udpServer.playerPositionLLA.y); // lat, lon
    }

    void UpdatePositionOnMap(double playerLatitude, double playerLongitude)
    {
        Vector2 localPosition = mapScript.GeographicToMapPosition(playerLatitude, playerLongitude);

        // Update the GameObject's position. Note: We assume the map is a UI element. For 3D positioning, adapt this line.
        RectTransform rectTransform = GetComponent<RectTransform>();
        if (rectTransform != null)
        {
            rectTransform.anchoredPosition = localPosition;
        }
    }
}