using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using UnityEngine.UI;
using TMPro; 

public class Altitude : MonoBehaviour
{
    public TMP_InputField altitudeInputField;
    public float targetAltitude;

    void Start()
    {
        if (altitudeInputField == null)
        {
            Debug.LogError("altitudeInputField is not assigned on " + gameObject.name);
            return; // Exit early to prevent further null reference exceptions
        }
        
        altitudeInputField.onEndEdit.AddListener(SubmitAltitude);
    }

    public void SubmitAltitude(string inputText)
    {     
        if (!string.IsNullOrEmpty(inputText))
        {
            // Attempt to convert the inputText to a float
            bool wasConversionSuccessful = float.TryParse(inputText, out targetAltitude);

            if (wasConversionSuccessful)
            {
                // Conversion successful, use the altitude value
                Debug.Log("Altitude value: " + targetAltitude);
            }
            else
            {
                // Conversion failed, inputText might not be a valid number
                Debug.LogWarning("Input text is not a valid number: " + inputText);
            }
        }
    }
}
