using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using UnityEngine.UI;
using TMPro; 

public class Geocoding : MonoBehaviour
{
    private readonly string baseUrl = "https://maps.googleapis.com/maps/api/geocode/json?";
    private string apiKey = "AIzaSyCCTlEkssUhFEDC-_hUE3-5sJfT2EWSw_M"; // Replace with your actual API key
    public TMP_InputField locationInputField;
    public MapScene2 mapScript;
    

    void Start()
    {
        if (locationInputField == null)
        {
            Debug.LogError("LocationInputField is not assigned on " + gameObject.name);
            return; // Exit early to prevent further null reference exceptions
        }
        
        locationInputField.onEndEdit.AddListener(SubmitLocation);
    }

    public void SubmitLocation(string addressText)
    {
        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))
        {
            StartCoroutine(OnLocationFound(addressText)); // Initiate the coroutine to process the address
        }
    }

    IEnumerator OnLocationFound(string address)
    {
        string requestUrl = baseUrl + "address=" + UnityWebRequest.EscapeURL(address) + "&key=" + apiKey;
        using (UnityWebRequest webRequest = UnityWebRequest.Get(requestUrl))
        {
            yield return webRequest.SendWebRequest();
            if (webRequest.result == UnityWebRequest.Result.ConnectionError || webRequest.result == UnityWebRequest.Result.ProtocolError)
            {
                Debug.LogError("Geocoding API Error: " + webRequest.error);
            }
            else
            {
                ProcessGeocodingResponse(webRequest.downloadHandler.text);
            }
        }
    }

    void ProcessGeocodingResponse(string jsonResponse)
    {
        GeocodeJSONResponse response = JsonUtility.FromJson<GeocodeJSONResponse>(jsonResponse);
        if (response.results.Length > 0)
        {
            float lat = response.results[0].geometry.location.lat;
            float lng = response.results[0].geometry.location.lng;

            Debug.Log("Latitude: " + lat + ", Longitude: " + lng);

            // Assuming you've extracted lat and lon correctly, you would then update your Map script's variables
            mapScript.centerLatitude = lat;
            mapScript.centerLongitude = lng;

            // Optionally, trigger map update if you have such a method available
            mapScript.updateMap = true; // You might need to create or adjust this method in your Map script
        }
        else
        {
            Debug.LogError("No results found.");
        }
    }
}


[System.Serializable]
public class GeocodeJSONResponse
{
    public GeocodeResult[] results;
}

[System.Serializable]
public class GeocodeResult
{
    public GeocodeGeometry geometry;
}

[System.Serializable]
public class GeocodeGeometry
{
    public GeocodeLocation location;
}

[System.Serializable]
public class GeocodeLocation
{
    public float lat;
    public float lng;
}