using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using UnityEngine;
using System.Text.RegularExpressions;
using UnityEngine.Networking;
using System.Collections.Generic;
using TMPro;
using System.Collections.Concurrent;
using System;

public class UDPClient : MonoBehaviour
{
    private UdpClient client;
    private IPEndPoint serverEndPoint;

    [Header("Network Config.")]
    public string PC_IPAddress = "169.234.2.85"; // Replace with the server IP address (PC)
    public int wifiPort = 8080;
    // [SerializeField] private string playerCurrtLLA;
    [SerializeField] private Vector3D targetXYZ;


    private void Start()
    {
        Debug.Log($"Attempting to create UDP Client, targeting IP: {PC_IPAddress} on Port: {wifiPort}");
        
        client = new UdpClient();
        serverEndPoint = new IPEndPoint(IPAddress.Parse(PC_IPAddress), wifiPort);
        
        Debug.Log("UDP Client created. Beginning to receive messages...");

        client.BeginReceive(ReceiveCallback, null);
    }

    private void FixedUpdate()
    {
        string playerCurrtLLA = PlayerPosSingleton.Instance.CurrLLAData.x + ", " + PlayerPosSingleton.Instance.CurrLLAData.y + ", " + PlayerPosSingleton.Instance.CurrLLAData.z;
        // string updateMapAligment = mapAligment?.updateMapAligment.ToString();
        // string R_Map = mapAligment?.R_QR_HMD.ToString();
        // string q_Map = mapAligment?.q_QR_HMD.ToString();
        // string R_Player = pPlanning?.R_player.ToString();
        // string goalReached = pPlanning?.goalReached.ToString();

        // string clientMessage = updateMapAligment + ", " + R_Map + ", " + q_Map + ", " + R_Player + ", " + goalReached;
        // SendMessage(clientMessage);
        // print("Mssg sent: " + clientMessage);

        string clientMessage = playerCurrtLLA;
        SendMessage(clientMessage);
        // print("Mssg sent: " + clientMessage);
    }

    private void ReceiveCallback(IAsyncResult ar)
    {
        try
        {
            Debug.Log("Received callback triggered.");
            byte[] data = client.EndReceive(ar, ref serverEndPoint);
            string serverMessage = Encoding.ASCII.GetString(data);

            // Debug.Log("Server message received as: " + serverMessage);

            // Assign variables:
            Regex sc = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?");
            var matches_sc = sc.Matches(serverMessage);
            Debug.Log("Server message num of matches: " + matches_sc.Count);
            if (matches_sc.Count == 3)
            {
                TargetPosSingleton.Instance.SetLLAData(double.Parse(matches_sc[0].Value), double.Parse(matches_sc[1].Value), double.Parse(matches_sc[2].Value));
                targetXYZ = new Vector3D(double.Parse(matches_sc[0].Value), double.Parse(matches_sc[1].Value), double.Parse(matches_sc[2].Value));
            }
            
            // Debug.Log("Continuing to listen for messages...");
            client.BeginReceive(ReceiveCallback, null);
        }
        catch (Exception e)
        {
            Debug.LogError("Error in ReceiveCallback: " + e.ToString());
        }
    }

    private void SendMessage(string clientMessage)
    {
        // Debug.Log($"Attempting to send message: {clientMessage}");
        byte[] data = Encoding.ASCII.GetBytes(clientMessage);
        client.Send(data, data.Length, serverEndPoint);
        // Debug.Log("Client sent the message - should be received by the server");
    }
}


// when trying to interact with Unity's UI elements (like TextMeshProUGUI) from a thread other than the main Unity thread.
// Unity's engine is not thread-safe, which means that most operations involving Unity objects, particularly those that 
// affect scene objects and their properties, need to be conducted on the main thread. This includes setting text on a UI
// component, enabling/disabling GameObjects, and instantiating new GameObjects. The asynchronous callback ReceiveCallback
// from UdpClient.BeginReceive does not execute on the main Unity thread. When you attempt to update wifiTextDebug.text
// within this callback, Unity detects that it is an interaction with scene objects from a background thread and throws
// the exception.