//                         UDPServer SCRIPT:
//-----------------------------------------------------------------------
// ML2 actuates as a server and receive data via UDP from the client HP
// Received data:
//  - Timestamp
//  - LiDAR
//  - Buttons
//  - GPS
//-----------------------------------------------------------------------

using System;
using System.Net;
using System.Text;
using UnityEngine;
using System.Net.Sockets;
using System.Collections;
using System.Text.RegularExpressions;

public class UDPServer : MonoBehaviour
{
    private UdpClient server;
    private IPEndPoint clientEndPoint;

    [Header("Network Config.")]
    public int wifiPort = 8081;

    [Header("Receiver Parameters:")]
    public float timestamp;
    public float lidarDist;
    public int button_1 = 0; // 0 not pressed; 1 pressed; (switch)
    public int button_2 = 1; // 1 not pressed; 0 pressed; (back button)
    public int button_3 = 1; // 1 not pressed; 0 pressed; (back button)
    public Vector3 gps;

    public bool messageReceived = false;
    private float timeoutDuration = 0.25f; // Adjust the timeout duration as needed
    private float lastReceiveTime;

    private void Start()
    {
        server = new UdpClient(wifiPort);
        clientEndPoint = new IPEndPoint(IPAddress.Any, 0);

        // Start receiving messages
        server.BeginReceive(ReceiveCallback, null);
    }

    private void FixedUpdate()
    {
        // Check for timeout
        if (messageReceived && Time.time - lastReceiveTime > timeoutDuration)
        {
            messageReceived = false;
        }

        // Send mssg if needed
    }

    private void ReceiveCallback(IAsyncResult ar)
    {
        byte[] data = server.EndReceive(ar, ref clientEndPoint);
        string clientMessage = Encoding.ASCII.GetString(data);

        Debug.Log("client message received as: " + clientMessage);

        // Assign variables:
        Regex sc = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?");
        var matches_sc = sc.Matches(clientMessage);
        Debug.Log("client message num of matches: " + matches_sc.Count);
        if (matches_sc.Count == 5)  // 8
        {
            timestamp = float.Parse(matches_sc[0].Value);
            lidarDist = float.Parse(matches_sc[1].Value);
            button_1 = int.Parse(matches_sc[2].Value);    // switch
            button_2 = int.Parse(matches_sc[3].Value);    // back button
            button_3 = int.Parse(matches_sc[4].Value);    // back button
            // gps = new Vector3(float.Parse(matches_sc[5].Value), float.Parse(matches_sc[6].Value), float.Parse(matches_sc[7].Value));
        } else { 
            print("num of matches: " + matches_sc.Count);
        }

        // Set the messageReceived flag to true
        messageReceived = true;
        lastReceiveTime = Time.time;

        // Continue receiving messages
        server.BeginReceive(ReceiveCallback, null);
    }

    private new void SendMessage(string serverMessage)
    {
        byte[] data = Encoding.ASCII.GetBytes(serverMessage);
        server.Send(data, data.Length, clientEndPoint);
        Debug.Log("Server sent his message - should be received by client");

        // Continue receiving messages
        server.BeginReceive(ReceiveCallback, null);
    }
}