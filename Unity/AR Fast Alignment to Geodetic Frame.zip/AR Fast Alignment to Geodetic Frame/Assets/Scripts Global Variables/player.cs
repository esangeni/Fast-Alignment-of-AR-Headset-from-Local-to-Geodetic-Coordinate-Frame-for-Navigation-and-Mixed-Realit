using UnityEngine;
using UnityEngine.InputSystem;
using System;
using System.Collections;
using System.Collections.Generic;

public class player : MonoBehaviour
{
    [SerializeField] private InputActionProperty headposePositionInputAction;
    [SerializeField] private InputActionProperty headposeRotationInputAction;
    [SerializeField] Vector3 headMLPosePosition;
    [SerializeField] Quaternion headMLPoseRotation;
    
    void Start()
    {
        if (headposePositionInputAction != null)
        {
            headposePositionInputAction.action.Enable();
            headposePositionInputAction.action.performed += mlPositionChanged;
        }
        if (headposeRotationInputAction != null)
        {
            headposeRotationInputAction.action.Enable();
            headposeRotationInputAction.action.performed += mlRotationChanged;
        }

        // Initialize the player position on the sigleton:
        // PlayerPosSingleton.Instance.SetInitLLAData(33.64321442493023, -117.83979961145577, 0); // MACS Area
        PlayerPosSingleton.Instance.SetInitLLAData(33.64321245745905, -117.84020287319062, 0);    // Outdoor EGateway Area
        Debug.Log("Initial Player LLA: " + PlayerPosSingleton.Instance.InitLLAData.x + ", " + PlayerPosSingleton.Instance.InitLLAData.y + ", " + PlayerPosSingleton.Instance.InitLLAData.z);
        // INITIAL VALUES PLAYER POSITION:
        // 1. Convert LLA to ECEF frames:
        var playerInitECEF = CoordsConverter.ConvertLLAToECEF(PlayerPosSingleton.Instance.InitLLAData);
        PlayerPosSingleton.Instance.SetInitECEFData(playerInitECEF.x, playerInitECEF.y, playerInitECEF.z);
        Debug.Log("Initial Player ECEF: " + PlayerPosSingleton.Instance.InitECEFData.x + ", " + PlayerPosSingleton.Instance.InitECEFData.y + ", " + PlayerPosSingleton.Instance.InitECEFData.z);
        // 2. Convert ECEF to ENU frame with center point initial fighter position:
        var playerInitENU = new Vector3D(0, 0, 0);
        PlayerPosSingleton.Instance.SetInitENUData(playerInitENU.x, playerInitENU.y, playerInitENU.z);
        Debug.Log("Initial Player ENU: " + PlayerPosSingleton.Instance.InitENUData.x + ", " + PlayerPosSingleton.Instance.InitENUData.y + ", " + PlayerPosSingleton.Instance.InitENUData.z);
        // 3. Adapt ENU frame to Unity's frame
        var playerInitEUN = CoordsConverter.ConvertENUtoUnityEUN(PlayerPosSingleton.Instance.InitENUData);
        PlayerPosSingleton.Instance.SetInitXYZData(playerInitEUN.x, playerInitEUN.y, playerInitEUN.z);
        Debug.Log("Initial Player XYZ: " + PlayerPosSingleton.Instance.InitXYZData.x + ", " + PlayerPosSingleton.Instance.InitXYZData.y + ", " + PlayerPosSingleton.Instance.InitXYZData.z);
    }

    void Update()
    {
        // UPDATE VALUES PLAYER POSITION:
        // Read ML head position:
        PlayerPosSingleton.Instance.SetCurrXYZData(headMLPosePosition.x, headMLPosePosition.y, headMLPosePosition.z);
        
        // Adapt Current ML Unity's frame frame to ENU:
        var playerCurrENU = CoordsConverter.ConvertUnityEUNtoENU(PlayerPosSingleton.Instance.CurrXYZData);
        PlayerPosSingleton.Instance.SetCurrENUData(playerCurrENU.x, playerCurrENU.y, playerCurrENU.z);
        
        // Convert ENU to ECEF frame with center point initial fighter position:
        var playerCurrECEF = CoordsConverter.ConvertENUToECEF(PlayerPosSingleton.Instance.InitLLAData, PlayerPosSingleton.Instance.CurrENUData, PlayerPosSingleton.Instance.InitECEFData);
        PlayerPosSingleton.Instance.SetCurrECEFData(playerCurrECEF.x, playerCurrECEF.y, playerCurrECEF.z);
        
        // Convert ECEF to LLA frame:
        var playerLLAENU = CoordsConverter.ConvertECEFoLLA(PlayerPosSingleton.Instance.CurrECEFData);
        PlayerPosSingleton.Instance.SetCurrLLAData(playerLLAENU.x, playerLLAENU.y, playerLLAENU.z);

        //--------

        // Alignment to TN:
        int misalignmentRotationOffset = AligmentRotationSingleton.Instance.aligmentRotOffset;
        // Quaternion misalignmentRotation = Quaternion.Euler(0, -misalignmentRotationOffset+180, 0);

        double heading = Math.PI * (-misalignmentRotationOffset + 180) / 180.0; // convert degrees to radians
        // 1. Convert into Unity World Coordinates
        Vector3 UWCLeft = RotateY(new Vector3((float)PlayerPosSingleton.Instance.CurrXYZData.x, (float)PlayerPosSingleton.Instance.CurrXYZData.y, (float)PlayerPosSingleton.Instance.CurrXYZData.z), heading);

        // 2. Convert Left-Handed to Right-Handed Coordinate System
        Vector3D UWCRight = new Vector3D(UWCLeft.x, UWCLeft.y, -UWCLeft.z);
        PlayerPosSingleton.Instance.SetCurrXYZAlignData(UWCRight.x, UWCRight.y, UWCRight.z);

        // 3. Convert Unity (Right-Handed) to ENU Coordinate System
        Vector3 ENU = ConvertUnityToENU(new Vector3((float)UWCRight.x,(float)UWCRight.y,(float)UWCRight.z));
        PlayerPosSingleton.Instance.SetCurrENUAlignData(ENU.x, ENU.y, ENU.z);

        // 4. Convert ENU to ECEF and Further Conversion
        Vector3D playerCurrECEFAlign = CoordsConverter.ConvertENUToECEF(PlayerPosSingleton.Instance.InitLLAData, new Vector3D(ENU.x, ENU.y, ENU.z), PlayerPosSingleton.Instance.InitECEFData);
        PlayerPosSingleton.Instance.SetCurrECEFAlignData(playerCurrECEFAlign.x, playerCurrECEFAlign.y, playerCurrECEFAlign.z);

        Vector3D playerLLAENUAlign = CoordsConverter.ConvertECEFoLLA(playerCurrECEFAlign);
        PlayerPosSingleton.Instance.SetCurrLLAAlginData(playerLLAENUAlign.x, playerLLAENUAlign.y, playerLLAENUAlign.z);
    }

    Vector3 RotateY(Vector3 v, double theta)
    {
        double cosTheta = Math.Cos(theta);
        double sinTheta = Math.Sin(theta);

        double[,] R_y = {
            {cosTheta, 0, sinTheta},
            {0, 1, 0},
            {-sinTheta, 0, cosTheta},
        };

        return new Vector3(
            (float)(R_y[0,0] * v.x + R_y[0,1] * v.y + R_y[0,2] * v.z),
            (float)(R_y[1,0] * v.x + R_y[1,1] * v.y + R_y[1,2] * v.z),
            (float)(R_y[2,0] * v.x + R_y[2,1] * v.y + R_y[2,2] * v.z)
        );
    }

    Vector3 ConvertUnityToENU(Vector3 v)
    {
        float[,] unityToENU = {
            {1, 0, 0},
            {0, 0, -1},
            {0, 1, 0},
        };

        return new Vector3(
            (unityToENU[0,0] * v.x + unityToENU[0,1] * v.y + unityToENU[0,2] * v.z),
            (unityToENU[1,0] * v.x + unityToENU[1,1] * v.y + unityToENU[1,2] * v.z),
            (unityToENU[2,0] * v.x + unityToENU[2,1] * v.y + unityToENU[2,2] * v.z)
        );
    }

    private void mlPositionChanged(InputAction.CallbackContext obj)
    {
        headMLPosePosition = obj.ReadValue<Vector3>();        
    }

    private void mlRotationChanged(InputAction.CallbackContext obj)
    {
        headMLPoseRotation = obj.ReadValue<Quaternion>();        
    }
}
