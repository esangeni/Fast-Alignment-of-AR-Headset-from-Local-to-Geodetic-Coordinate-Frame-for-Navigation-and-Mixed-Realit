using UnityEngine;
public class HPPosSingleton : MonoBehaviour
{
    private static HPPosSingleton _instance;
    public static HPPosSingleton Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<HPPosSingleton>();
                if (_instance == null)
                {
                    GameObject obj = new GameObject("HPPosSingleton");
                    _instance = obj.AddComponent<HPPosSingleton>();
                    DontDestroyOnLoad(obj);
                }
            }
            return _instance;
        }
    }

    public Vector3D InitLLAData { get; private set; }   // initial values LLA-frame
    public Vector3D InitECEFData { get; private set; }  // initial values ECEF-frame
    public Vector3D InitENUData { get; private set; } // initial values enu-frame
    public Vector3D InitXYZData { get; private set; } // initial values unity-frame
    //----------
    public Vector3D CurrLLAData { get; private set; } // current values unity-frame
    public Vector3D CurrECEFData { get; private set; } // current values unity-frame
    public Vector3D CurrENUData { get; private set; } // current values unity-frame
    public Vector3D CurrXYZData { get; private set; } // current values unity-frame
    public Vector3 CurrRollPitchYawData { get; private set; } // current orientation unity-frame

    void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;

            // Initialize Player Position with default values
            InitLLAData = new Vector3D(33.643211255612904, -117.83980115803249, 0);  // LLA: Latitude, Longitude, Altitude
            InitECEFData = new Vector3D(0, 0, 0); // XYZ: center earth
            InitENUData = new Vector3D(0, 0, 0);  // ENU: frame
            InitXYZData = new Vector3D(0, 0, 0);  // XYZ: Unity world space position
            //-------------
            CurrLLAData = new Vector3D(0, 0, 0);  // XYZ: Unity world space position
            CurrECEFData = new Vector3D(0, 0, 0);  // XYZ: center earth
            CurrENUData = new Vector3D(0, 0, 0);  // ENU: frame
            CurrXYZData = new Vector3D(0, 0, 0);  // XYZ: Unity world space position
            //-------------
            CurrRollPitchYawData = new Vector3(0, 0, 0);
        }
    }

    // Method to set LLA data
    public void SetInitLLAData(double lat, double lon, double alt)
    {
        InitLLAData = new Vector3D(lat, lon, alt);
    }

    public void SetInitECEFData(double x, double y, double z)
    {
        InitECEFData = new Vector3D(x, y, z);
    }

    public void SetInitENUData(double E, double N, double U)
    {
        InitENUData = new Vector3D(E, N, U);
    }

    public void SetInitXYZData(double x, double y, double z)
    {
        InitXYZData = new Vector3D(x, y, z);
    }

    //--------

    public void SetCurrLLAData(double lat, double lon, double alt)
    {
        CurrLLAData = new Vector3D(lat, lon, alt);
    }

    public void SetCurrECEFData(double x, double y, double z)
    {
        CurrECEFData = new Vector3D(x, y, z);
    }

    public void SetCurrENUData(double E, double N, double U)
    {
        CurrENUData = new Vector3D(E, N, U);
    }

    public void SetCurrXYZData(double x, double y, double z)
    {
        CurrXYZData = new Vector3D(x, y, z);
    }

    public void SetCurrRollPitchYawData(float roll, float pitch, float yaw)
    {
        CurrRollPitchYawData = new Vector3(roll, pitch, yaw);
    }
}

// On other classes:
// -----------------
// Set Lat, Lon, Alt values:
// HPPosSingleton.Instance.SetInitLLAData(37.7749, -122.4194, 15.0);
// HPPosSingleton.Instance.SetInitXYZData(37.7749, -122.4194, 15.0);
// HPPosSingleton.Instance.SetCurrXYZData(37.7749, -122.4194, 15.0);

// // Access and use the data:
// Vector3D data = HPPosSingleton.Instance.initLLAData;
// Vector3D data = HPPosSingleton.Instance.initECEFData;
// Vector3D data = HPPosSingleton.Instance.initENUData;
// Vector3D data = HPPosSingleton.Instance.initXYZData;
// Debug.Log($"Lat: {data.x}, Lon: {data.y}, Alt: {data.z}");