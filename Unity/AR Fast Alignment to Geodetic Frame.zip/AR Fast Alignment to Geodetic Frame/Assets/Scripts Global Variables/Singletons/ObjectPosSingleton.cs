using UnityEngine;

public class ObjectPosSingleton : MonoBehaviour
{
    private static ObjectPosSingleton _instance;
    public static ObjectPosSingleton Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<ObjectPosSingleton>();
                if (_instance == null)
                {
                    GameObject obj = new GameObject("ObjectPosSingleton");
                    _instance = obj.AddComponent<ObjectPosSingleton>();
                    DontDestroyOnLoad(obj);
                }
            }
            return _instance;
        }
    }

    public Vector3D CurrLLAData { get; private set; }
    public Vector3D CurrECEFData { get; private set; }
    public Vector3D CurrENUData { get; private set; }
    public Vector3D CurrXYZData { get; private set; }

    void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;

            // Initialize Player Position with default values
            CurrLLAData = new Vector3D(0, 0, 0);  // LLA: Latitude, Longitude, Altitude
            CurrECEFData = new Vector3D(0, 0, 0); // XYZ: center earth
            CurrENUData = new Vector3D(0, 0, 0);  // ENU: frame
            CurrXYZData = new Vector3D(0, 0, 0);  // XYZ: Unity world space position
        }
    }

    // Method to set LLA data
    public void SetCurrLLAData(double lat, double lon, double alt)
    {
        CurrLLAData = new Vector3D(lat, lon, alt);
    }

    public void SetCurrECEFData(double x, double y, double z)
    {
        CurrECEFData = new Vector3D(x, y, z);
    }

    public void SetCurrENUData(double E, double N, double U)
    {
        CurrENUData = new Vector3D(E, N, U);
    }

    // Method to set XYZ data
    public void SetCurrXYZData(double x, double y, double z)
    {
        CurrXYZData = new Vector3D(x, y, z);
    }
}

// // On other classes:
// // -----------------
// // Set Lat, Lon, Alt values:
// // ObjectPosSingleton.Instance.SetLLAData(37.7749, -122.4194, 15.0);
// // ObjectPosSingleton.Instance.SetECEFData(0, 0, 0);
// // ObjectPosSingleton.Instance.SetENUData(0, 0, 0);
// // ObjectPosSingleton.Instance.SetXYZData(0, 0, 0);

// // // Access and use the data:
// // Vector3D data = ObjectPosSingleton.Instance.LLAData;
// // Vector3D data = ObjectPosSingleton.Instance.ECEFData;
// // Vector3D data = ObjectPosSingleton.Instance.ENUData;
// // Vector3D data = ObjectPosSingleton.Instance.XYZData;
// // Debug.Log($"Lat: {data.x}, Lon: {data.y}, Alt: {data.z}");