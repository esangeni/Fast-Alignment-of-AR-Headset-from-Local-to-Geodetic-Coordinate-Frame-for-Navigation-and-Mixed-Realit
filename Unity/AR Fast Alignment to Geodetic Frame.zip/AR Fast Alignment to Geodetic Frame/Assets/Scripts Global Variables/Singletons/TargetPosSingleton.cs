using UnityEngine;

public class TargetPosSingleton : MonoBehaviour
{
    private static TargetPosSingleton _instance;
    public static TargetPosSingleton Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<TargetPosSingleton>();
                if (_instance == null)
                {
                    GameObject obj = new GameObject("TargetPosSingleton");
                    _instance = obj.AddComponent<TargetPosSingleton>();
                    DontDestroyOnLoad(obj);
                }
            }
            return _instance;
        }
    }

    public Vector3D LLAData { get; private set; }
    public Vector3D ECEFData { get; private set; }
    public Vector3D ENUData { get; private set; }
    public Vector3D XYZData { get; private set; }

    void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;

            // Initialize Player Position with default values
            LLAData = new Vector3D(0, 0, 0);  // LLA: Latitude, Longitude, Altitude
            ECEFData = new Vector3D(0, 0, 0); // XYZ: center earth
            ENUData = new Vector3D(0, 0, 0);  // ENU: frame
            XYZData = new Vector3D(0, 0, 0);  // XYZ: Unity world space position
        }
    }

    // Method to set LLA data
    public void SetLLAData(double lat, double lon, double alt)
    {
        LLAData = new Vector3D(lat, lon, alt);
    }

    public void SetECEFData(double x, double y, double z)
    {
        ECEFData = new Vector3D(x, y, z);
    }

    public void SetENUData(double E, double N, double U)
    {
        ENUData = new Vector3D(E, N, U);
    }

    // Method to set XYZ data
    public void SetXYZData(double x, double y, double z)
    {
        XYZData = new Vector3D(x, y, z);
    }
}

// // On other classes:
// // -----------------
// // Set Lat, Lon, Alt values:
// // TargetPosSingleton.Instance.SetLLAData(37.7749, -122.4194, 15.0);
// // TargetPosSingleton.Instance.SetECEFData(0, 0, 0);
// // TargetPosSingleton.Instance.SetENUData(0, 0, 0);
// // TargetPosSingleton.Instance.SetXYZData(0, 0, 0);

// // // Access and use the data:
// // Vector3D data = TargetPosSingleton.Instance.LLAData;
// // Vector3D data = TargetPosSingleton.Instance.ECEFData;
// // Vector3D data = TargetPosSingleton.Instance.ENUData;
// // Vector3D data = TargetPosSingleton.Instance.XYZData;
// // Debug.Log($"Lat: {data.x}, Lon: {data.y}, Alt: {data.z}");