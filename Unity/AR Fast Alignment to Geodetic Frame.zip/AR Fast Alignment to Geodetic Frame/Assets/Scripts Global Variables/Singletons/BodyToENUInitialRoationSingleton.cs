using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BodyToENUInitialRoationSingleton : MonoBehaviour
{
    private static BodyToENUInitialRoationSingleton _instance;
    public static BodyToENUInitialRoationSingleton Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<BodyToENUInitialRoationSingleton>();
                if (_instance == null)
                {
                    GameObject obj = new GameObject("BodyToENUInitialRoationSingleton");
                    _instance = obj.AddComponent<BodyToENUInitialRoationSingleton>();
                    DontDestroyOnLoad(obj);
                }
            }
            return _instance;
        }
    }

    private float QRToNorthAngle = 48; // 48f [deg]
    public Quaternion q_BodyToTag { get; private set; } // current values unity-frame
    public Quaternion q_TagToTrueNorth { get; private set; }
    public bool isTagDetected { get; private set; } // current values enu-frame

    void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;

            q_BodyToTag = new Quaternion();  // Unity-frame
            q_TagToTrueNorth = Quaternion.Euler(0, -QRToNorthAngle, 0);  // XYZ: Unity world space position
        }
    }

    public void Setq_BodyToTagData(Quaternion q) // ML rotation directly
    {
        q_BodyToTag = q;
        // q_BodyToTag = Quaternion.Inverse(q);
    }

    public void SetIsTagDetected(bool isDetected)
    {
        isTagDetected = isDetected;
    }
}