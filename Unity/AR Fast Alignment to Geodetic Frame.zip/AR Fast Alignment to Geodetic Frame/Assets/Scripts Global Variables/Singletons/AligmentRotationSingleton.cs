using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AligmentRotationSingleton : MonoBehaviour
{
    private static AligmentRotationSingleton _instance;
    public static AligmentRotationSingleton Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<AligmentRotationSingleton>();
                if (_instance == null)
                {
                    GameObject obj = new GameObject("AligmentRotationSingleton");
                    _instance = obj.AddComponent<AligmentRotationSingleton>();
                    DontDestroyOnLoad(obj);
                }
            }
            return _instance;
        }
    }

    public int aligmentRotOffset; // 48f [deg]

    void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;

            aligmentRotOffset = 0;
        }
    }

    public void SetAligRotOffset(int f) // ML rotation directly
    {
        aligmentRotOffset = f;
    }
}