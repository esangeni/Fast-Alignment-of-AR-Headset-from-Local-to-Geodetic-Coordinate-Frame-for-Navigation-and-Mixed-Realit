using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneChangeSingleton : MonoBehaviour
{
    private static SceneChangeSingleton _instance;
    public static SceneChangeSingleton Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<SceneChangeSingleton>();
                if (_instance == null)
                {
                    GameObject obj = new GameObject("SceneChangeSingleton");
                    _instance = obj.AddComponent<SceneChangeSingleton>();
                    DontDestroyOnLoad(obj);
                }
            }
            return _instance;
        }
    }

    public bool isSceneChanged; // 48f [deg]

    void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;

            isSceneChanged = false;
        }
    }

    public void SetIsSceneChanged(bool isSceneChanged) // ML rotation directly
    {
        isSceneChanged = true;
    }
}