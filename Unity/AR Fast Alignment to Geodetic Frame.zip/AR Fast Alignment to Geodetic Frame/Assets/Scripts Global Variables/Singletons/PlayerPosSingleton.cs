using UnityEngine;
public class PlayerPosSingleton : MonoBehaviour
{
    private static PlayerPosSingleton _instance;
    public static PlayerPosSingleton Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType<PlayerPosSingleton>();
                if (_instance == null)
                {
                    GameObject obj = new GameObject("PlayerPosSingleton");
                    _instance = obj.AddComponent<PlayerPosSingleton>();
                    DontDestroyOnLoad(obj);
                }
            }
            return _instance;
        }
    }

    public Vector3D InitLLAData { get; private set; }  // initial values LLA-frame
    public Vector3D InitECEFData { get; private set; } // initial values ECEF-frame
    public Vector3D InitENUData { get; private set; } // initial values enu-frame
    public Vector3D InitXYZData { get; private set; } // initial values unity-frame
    //----------
    public Vector3D CurrLLAData { get; private set; } // current values unity-frame
    public Vector3D CurrECEFData { get; private set; } // current values unity-frame
    public Vector3D CurrENUData { get; private set; } // current values unity-frame
    public Vector3D CurrXYZData { get; private set; } // current values unity-frame
    //-----------
    public Vector3D CurrLLAAlignData { get; private set; } // current values unity-frame
    public Vector3D CurrECEFAlignData { get; private set; } // current values unity-frame
    public Vector3D CurrENUAlignData { get; private set; } // current values unity-frame
    public Vector3D CurrXYZAlignData { get; private set; } // current values unity-frame


    void Awake()
    {
        if (_instance != null && _instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            _instance = this;

            // Initialize Player Position with default values
            // InitLLAData = new Vector3D(33.643211255612904, -117.83980115803249, 0);  // LLA: Latitude, Longitude, Altitude (MACS Area)
            InitLLAData = new Vector3D(33.64321245745905, -117.84020287319062, 0);      // LLA: Latitude, Longitude, Altitude (Outdoor EGatway Area)
            InitECEFData = new Vector3D(0, 0, 0); // XYZ: center earth
            InitENUData = new Vector3D(0, 0, 0);  // ENU: frame
            InitXYZData = new Vector3D(0, 0, 0);  // XYZ: Unity world space position
            //-------------
            CurrLLAData = new Vector3D(0, 0, 0);  // XYZ: Unity world space position
            CurrECEFData = new Vector3D(0, 0, 0);  // XYZ: center earth
            CurrENUData = new Vector3D(0, 0, 0);  // ENU: frame
            CurrXYZData = new Vector3D(0, 0, 0);  // XYZ: Unity world space position
            //-------------
            CurrLLAAlignData = new Vector3D(0, 0, 0);
            CurrECEFAlignData = new Vector3D(0, 0, 0);
            CurrENUAlignData = new Vector3D(0, 0, 0);
            CurrXYZAlignData = new Vector3D(0, 0, 0);
        }
    }

    // Method to set LLA data
    public void SetInitLLAData(double lat, double lon, double alt)
    {
        InitLLAData = new Vector3D(lat, lon, alt);
    }

    public void SetInitECEFData(double x, double y, double z)
    {
        InitECEFData = new Vector3D(x, y, z);
    }

    public void SetInitENUData(double E, double N, double U)
    {
        InitENUData = new Vector3D(E, N, U);
    }

    public void SetInitXYZData(double x, double y, double z)
    {
        InitXYZData = new Vector3D(x, y, z);
    }

    //--------

    public void SetCurrLLAData(double lat, double lon, double alt)
    {
        CurrLLAData = new Vector3D(lat, lon, alt);
    }

    public void SetCurrECEFData(double x, double y, double z)
    {
        CurrECEFData = new Vector3D(x, y, z);
    }

    public void SetCurrENUData(double E, double N, double U)
    {
        CurrENUData = new Vector3D(E, N, U);
    }

    public void SetCurrXYZData(double x, double y, double z)
    {
        CurrXYZData = new Vector3D(x, y, z);
    }
    
    //--------

    public void SetCurrLLAAlginData(double lat, double lon, double alt)
    {
        CurrLLAAlignData = new Vector3D(lat, lon, alt);
    }

    public void SetCurrECEFAlignData(double x, double y, double z)
    {
        CurrECEFAlignData = new Vector3D(x, y, z);
    }

    public void SetCurrENUAlignData(double E, double N, double U)
    {
        CurrENUAlignData = new Vector3D(E, N, U);
    }

    public void SetCurrXYZAlignData(double x, double y, double z)
    {
        CurrXYZAlignData = new Vector3D(x, y, z);
    }
}

// On other classes:
// -----------------
// Set Lat, Lon, Alt values:
// PlayerPosSingleton.Instance.SetInitLLAData(37.7749, -122.4194, 15.0);
// PlayerPosSingleton.Instance.SetInitXYZData(37.7749, -122.4194, 15.0);
// PlayerPosSingleton.Instance.SetCurrXYZData(37.7749, -122.4194, 15.0);

// // Access and use the data:
// Vector3D data = PlayerPosSingleton.Instance.initLLAData;
// Vector3D data = PlayerPosSingleton.Instance.initECEFData;
// Vector3D data = PlayerPosSingleton.Instance.initENUData;
// Vector3D data = PlayerPosSingleton.Instance.initXYZData;
// Debug.Log($"Lat: {data.x}, Lon: {data.y}, Alt: {data.z}");