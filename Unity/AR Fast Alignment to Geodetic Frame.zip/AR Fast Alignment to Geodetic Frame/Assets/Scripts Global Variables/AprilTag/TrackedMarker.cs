using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.MagicLeap;
/// <summary>
/// Class used to keep track of markers that have already been detected.
/// </summary>
public class TrackedMarker
{
    public uint Id;
    public float LastTrackTime { get; private set; }
    public Vector3 Position { get; private set; }
    public Quaternion Rotation { get; private set; }

    public float Size { get; private set; } // Add Size property

    public TrackedMarker(MLMarkerTracker.MarkerData data, float size)
    {
        Id = data.ArucoData.Id;

        Size = size;

        UpdateMarker(data);
    }

    public void UpdateMarker(MLMarkerTracker.MarkerData data)
    {
        //You can perform smoothing here
        Position = data.Pose.position;
        Rotation = data.Pose.rotation;

        LastTrackTime = Time.time;
    }
}