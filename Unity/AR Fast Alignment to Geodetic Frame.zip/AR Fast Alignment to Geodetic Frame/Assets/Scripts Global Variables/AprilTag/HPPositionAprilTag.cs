using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.Rendering.Universal;
using UnityEngine.XR.MagicLeap;
using UnityEngine.InputSystem;

public class HPPositionAprilTag : MonoBehaviour
{
    #region private members
    private string id = "";
    private Dictionary<uint, GameObject> _markerById = new Dictionary<uint, GameObject>();
    #endregion

    #region public members
    [Header("Public Dependencies:")]
    public MagicLeapCamera MagicLeapCamera;
    public LayerMask cubeLayerMask;
    public MagicLeapInputs mlInputs;   // ML2 Inputs
    public MagicLeapInputs.HMDActions hmdActions;        // Head Mounted Device actions

    [Header("Marker Settings:")]
    public float markerSize = 0.173f;

    [Header("HMD {R, q} respect to unity:")]
    public Vector3 R_HMD_unity;     // position HMD respect n
    public Quaternion q_HMD_unity;  // rotation HMD respect n

    [Header("QR {R, q} respect to HMD:")]
    public Vector3 R_QR_HMD;        // position QR respect HMD
    public Quaternion q_QR_HMD;     // rotation QR respect HMD

    [Header("HP {R, q} respect to unity:")]
    public Vector3 R_HP_HMD;        // position HP respect HMD
    public Quaternion q_HP_HMD;     // rotation HP respect HMD

    [Header("Map Update:")]
    public int updateMapAligment = 0;

    [Header("HP Update:")]
    public int updateHPAligment = 0;
    #endregion
    
    void Start(){

        // Enable ML inputs:
        mlInputs = new MagicLeapInputs();
        mlInputs.Enable();
        hmdActions = new MagicLeapInputs.HMDActions(mlInputs);    // Head Mounted Device actions

        //Tracking markers:
        TrackingMarker.OnMarkerLost += MarkerLost;
        TrackingMarker.OnMarkerFound += MarkerFound;
        TrackingMarker.OnMarkerUpdated += MarkerUpdated;
    }

    void FixedUpdate() {
        //HMD position and orientation:
        R_HMD_unity = MagicLeapCamera.transform.position;
        q_HMD_unity = MagicLeapCamera.transform.rotation;
    }

    private void MarkerUpdated(TrackedMarker trackedMarker) {

        R_HMD_unity = MagicLeapCamera.transform.position;
        q_HMD_unity = MagicLeapCamera.transform.rotation;

        if(trackedMarker.Id == 1){ // HP marker

            markerSize = 0.03f;

            id = trackedMarker.Id.ToString();
            q_QR_HMD = trackedMarker.Rotation;
            R_QR_HMD = trackedMarker.Position;

            RenderCube(trackedMarker, markerSize, R_QR_HMD, q_QR_HMD, R_HMD_unity, q_HMD_unity);

            // Handheld Platform dependencies:
            // R_HP_HMD = R_QR_HMD;
            // q_HP_HMD = Quaternion.Euler(q_QR_HMD.eulerAngles + new Vector3(0,180,0));
            HPPosSingleton.Instance.SetCurrXYZData(R_QR_HMD.x, R_QR_HMD.y, R_QR_HMD.z);
            Vector3 eulAngles = q_QR_HMD.eulerAngles + new Vector3(0,180,0);
            HPPosSingleton.Instance.SetCurrRollPitchYawData(eulAngles.x, eulAngles.y, eulAngles.z);
            updateHPAligment = 1;
        } 
        else
        {
            // Handheld Platform dependencies:
            updateHPAligment = 0;
        }
    }

    private void MarkerFound(TrackedMarker trackedMarker) {

        if(trackedMarker.Id == 1)
        {
            markerSize = 0.03f;
            //Render the cube with the default URP shader:
            GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Cube);
            marker.layer = cubeLayerMask;
            // marker.AddComponent<Renderer>();
            // marker.GetComponent<Renderer>().material = new Material(Shader.Find("Universal Render Pipeline/Lit"));

            marker.transform.localScale = new Vector3(markerSize, markerSize, markerSize);

            _markerById.Add(trackedMarker.Id, marker);

            id = trackedMarker.Id.ToString();
            q_QR_HMD = trackedMarker.Rotation;
            R_QR_HMD = trackedMarker.Position;

            marker.transform.position = R_QR_HMD;
            marker.transform.rotation = q_QR_HMD;
        } 
    }

    private void MarkerLost(TrackedMarker trackedMarker) {
        GameObject marker = _markerById[trackedMarker.Id];
        _markerById.Remove(trackedMarker.Id);
        updateMapAligment = 0;
        updateHPAligment = 0;
        Destroy(marker);
    }

    private void RenderCube(TrackedMarker trackedMarker, float markerSize, Vector3 R, Quaternion q, Vector3 R_HMD_unity, Quaternion q_HMD_unity){
        GameObject marker = _markerById[trackedMarker.Id];
        //Render the cube with the default URP shader
        // marker.layer = cubeLayerMask;
        // marker.AddComponent<Renderer>();
        // marker.GetComponent<Renderer>().material = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        // marker.transform.localScale = new Vector3(markerSize, markerSize, markerSize);
        

        //Add TextMeshPro Object for display : {R; q}
        GameObject textObject_qr_hmd = new GameObject("TextMeshPro Object");
        textObject_qr_hmd.transform.localScale = new Vector3(markerSize, markerSize, markerSize);
        textObject_qr_hmd.transform.position = R + Vector3.up*markerSize/1.5f;
        textObject_qr_hmd.transform.rotation = q;
        textObject_qr_hmd.transform.eulerAngles = textObject_qr_hmd.transform.eulerAngles + new Vector3(0,180,180);

        TextMeshPro t_qr_hmd = textObject_qr_hmd.AddComponent<TextMeshPro>();
        t_qr_hmd.fontSize = 0.5f;
        t_qr_hmd.alignment = TextAlignmentOptions.Center;
        t_qr_hmd.text = "R: " + (R).ToString("#.##") + "\nq: " + q.eulerAngles.ToString("#.##");
        Destroy(textObject_qr_hmd,0.02f);

        //Add TextMeshPro Object for display : {R; R_QR_HMD}
        GameObject textObject_HMD_Unity = new GameObject("TextMeshPro Object");
        textObject_HMD_Unity.transform.localScale = new Vector3(markerSize, markerSize, markerSize);
        textObject_HMD_Unity.transform.position = R - Vector3.up*markerSize/1.5f;
        textObject_HMD_Unity.transform.rotation = q;
        textObject_HMD_Unity.transform.eulerAngles = textObject_HMD_Unity.transform.eulerAngles + new Vector3(0,180,180);

        TextMeshPro t_HMD_Unity = textObject_HMD_Unity.AddComponent<TextMeshPro>();
        t_HMD_Unity.fontSize = 0.5f;
        t_HMD_Unity.alignment = TextAlignmentOptions.Center;
        t_HMD_Unity.text = "R_HMD_unity: " + (R_HMD_unity).ToString("#.##") + "\nq_HMD_unity: " + q_HMD_unity.eulerAngles.ToString("#.##");
        Destroy(textObject_HMD_Unity,0.02f);
    }
}