using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.MagicLeap;
/// <summary>
/// Example of tracking markers and then calling the on marker found/lost/updated events.
/// </summary>
public class TrackingMarker : MonoBehaviour
{
    [Header("ArucoMarkerSettings")]
    public float QrCodeMarkerSize = 0.173f; // [m]
    public float ArucoMarkerSize = 0.173f;  // [m]
    public float AprilTagID0_MarkerSize = 0.173f;  // [m]
    public float AprilTagID1_MarkerSize = 0.03f;   // [m]
    public MLMarkerTracker.MarkerType TrackedMarkerType = MLMarkerTracker.MarkerType.Aruco_April;
    public MLMarkerTracker.ArucoDictionaryName ArucoDict = MLMarkerTracker.ArucoDictionaryName.DICT_5X5_50;
    public MLMarkerTracker.Profile TrackerProfile = MLMarkerTracker.Profile.Default;
    
    [Header("TrackingSettings")] 
    [Tooltip("The amount of time a marker can remain not tracked before being considered as lost.")]
    public float LostTrackingDelay;
    public float UpdateDelay = 1;

    private float _lastTickTime;

    //Used to track mich markers have been detected.
    private Dictionary<uint, TrackedMarker> _trackedMarkerById = new Dictionary<uint, TrackedMarker>();

    //Used to check which markers have lost tracking
    private List<TrackedMarker> _markerToUpdate = new List<TrackedMarker>();

    public static Action<TrackedMarker> OnMarkerFound;
    public static Action<TrackedMarker> OnMarkerUpdated;
    public static Action<TrackedMarker> OnMarkerLost;

    void Update()
    {
        float currentTime = Time.time;
        //Only update the list if needed. Marker Tracking runs slower than the update loop.
        if (currentTime - _lastTickTime < UpdateDelay)  return;

        for (int i = _markerToUpdate.Count - 1; i >= 0; i--)
        {
            bool isStale = _markerToUpdate[i].LastTrackTime <= currentTime - LostTrackingDelay;
            if (isStale)
            {
                TrackedMarker marker = _markerToUpdate[i];
                _trackedMarkerById.Remove(marker.Id);
                _markerToUpdate.RemoveAt(i);
                OnMarkerLost?.Invoke(marker);
            }
        }
        _lastTickTime = currentTime;
    }

    private void OnEnable()
    {
        MLMarkerTracker.OnMLMarkerTrackerResultsFound += OnTrackerResults;
        StartTracking();
    }

    private void OnDisable()
    {
        MLMarkerTracker.OnMLMarkerTrackerResultsFound -= OnTrackerResults;
        StopTracking();
    }

    private void StartTracking()
    {
        // Unity has it's own value for Enum called Everything and sets it to -1
        MLMarkerTracker.MarkerType MarkerTypes = (int)TrackedMarkerType == -1 ? MLMarkerTracker.MarkerType.All : TrackedMarkerType;
        MLMarkerTracker.TrackerSettings trackerSettings = MLMarkerTracker.TrackerSettings.Create(
            true, TrackedMarkerType, QrCodeMarkerSize, ArucoDict, ArucoMarkerSize, TrackerProfile, default);
        _ = MLMarkerTracker.SetSettingsAsync(trackerSettings);
    }

    private  void StopTracking()
    {
        _ = MLMarkerTracker.StopScanningAsync();
    }

    private void OnTrackerResults(MLMarkerTracker.MarkerData markerData)
    {
        //Switch in case you are tracking multiple types
        switch (markerData.Type)
        {
            case MLMarkerTracker.MarkerType.Aruco_April:
                if (_trackedMarkerById.TryGetValue(markerData.ArucoData.Id, out TrackedMarker marker))
                {
                    marker.UpdateMarker(markerData);
                    OnMarkerUpdated?.Invoke(marker);
                }
                else
                {
                    float markerSize = (markerData.ArucoData.Id == 0) ? AprilTagID0_MarkerSize : AprilTagID1_MarkerSize; // Determine the marker size based on its ID
                    
                    if(markerData.ArucoData.Id == 0){
                        MLMarkerTracker.TrackerSettings trackerSettings = MLMarkerTracker.TrackerSettings.Create(
                            true, TrackedMarkerType, markerSize, ArucoDict, markerSize, TrackerProfile, default);   // accuracy!!!
                        _ = MLMarkerTracker.SetSettingsAsync(trackerSettings);
                    }
                    if(markerData.ArucoData.Id == 1){
                        MLMarkerTracker.TrackerSettings trackerSettings = MLMarkerTracker.TrackerSettings.Create(
                            true, TrackedMarkerType, markerSize, ArucoDict, markerSize, TrackerProfile, default); // speed !!!
                        _ = MLMarkerTracker.SetSettingsAsync(trackerSettings);
                    }

                    var newMarker = new TrackedMarker(markerData, markerSize); // Pass the size parameter
                    //Track the marker
                    _trackedMarkerById.Add(newMarker.Id, newMarker);
                    _markerToUpdate.Add(newMarker);
                    OnMarkerFound?.Invoke(newMarker);
                }
                break;
        }
    }
}