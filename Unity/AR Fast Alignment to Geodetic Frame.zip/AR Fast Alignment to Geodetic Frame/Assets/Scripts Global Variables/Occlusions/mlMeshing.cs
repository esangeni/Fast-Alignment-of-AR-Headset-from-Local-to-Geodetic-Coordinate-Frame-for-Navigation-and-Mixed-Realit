using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.MagicLeap;

public class mlMeshing : MonoBehaviour
{
    [SerializeField] MeshingSubsystemComponent meshingSubsystemComponent;
    private readonly MLPermissions.Callbacks mlPermissionsCallbacks = new MLPermissions.Callbacks();

    void Awake()
    {
        mlPermissionsCallbacks.OnPermissionGranted += MlPermissionsCallbacks_OnPermissionGranted;
        mlPermissionsCallbacks.OnPermissionDenied += MlPermissionsCallbacks_OnPermissionDenied;
        mlPermissionsCallbacks.OnPermissionDeniedAndDontAskAgain += MlPermissionsCallbacks_OnPermissionDenied;
    }
    void Start()
    {
        // Request permission at start
        MLPermissions.RequestPermission(MLPermission.SpatialMapping, mlPermissionsCallbacks);
        // Get meshing subsystem
        meshingSubsystemComponent = FindObjectOfType<MeshingSubsystemComponent>();
    }
    // Disable meshing subsystem
    private void MlPermissionsCallbacks_OnPermissionDenied(string permission)
    {
        meshingSubsystemComponent.enabled = false;
    }
    // Enable meshing subsytem
    private void MlPermissionsCallbacks_OnPermissionGranted(string permission)
    {
        meshingSubsystemComponent.enabled = true;
    }
    private void OnDestroy()
    {
        // Unsubscribe from permission events
        mlPermissionsCallbacks.OnPermissionGranted -= MlPermissionsCallbacks_OnPermissionGranted;
        mlPermissionsCallbacks.OnPermissionDenied -= MlPermissionsCallbacks_OnPermissionDenied;
        mlPermissionsCallbacks.OnPermissionDeniedAndDontAskAgain -= MlPermissionsCallbacks_OnPermissionDenied;
    }
}
