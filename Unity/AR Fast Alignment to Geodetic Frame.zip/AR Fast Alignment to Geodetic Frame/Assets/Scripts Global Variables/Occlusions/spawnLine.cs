using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class spawnLine : MonoBehaviour
{
    public Vector3 startPoint;
    public Vector3 endPoint;
    private LineRenderer lineRenderer;
    private GameObject colliderObject; // GameObject that holds the collider

    void Start()
    {
        lineRenderer = gameObject.AddComponent<LineRenderer>();
        lineRenderer.material = new Material(Shader.Find("Standard"));
        lineRenderer.startWidth = 0.01f;
        lineRenderer.endWidth = 0.01f;
        lineRenderer.positionCount = 2;

        // Initialize the collider object
        colliderObject = new GameObject("LineCollider");
        colliderObject.transform.parent = this.transform; // Set the collider object as a child of this object

        // Add a CapsuleCollider
        CapsuleCollider capsule = colliderObject.AddComponent<CapsuleCollider>();
        capsule.radius = lineRenderer.startWidth; // Assuming the line width is consistent
        capsule.center = Vector3.zero;
        // Set the capsule to be vertical initially,
        // we'll adjust its orientation to match the line later.
        capsule.direction = 2; // Z-axis for direction

        // Initial setup
        UpdateLinePositions();
    }

    void Update()
    {
        UpdateLinePositions();
    }

    private void UpdateLinePositions()
    {
        if (startPoint != null && endPoint != null)
        {
            // Update the line renderer
            lineRenderer.SetPosition(0, startPoint);
            lineRenderer.SetPosition(1, endPoint);

            // Update the collider to match the line
            UpdateColliderPosition();
        }
    }

    private void UpdateColliderPosition()
    {
        Vector3 midPoint = (startPoint + endPoint) / 2;
        colliderObject.transform.position = midPoint; // Position at the midpoint of the line

        CapsuleCollider capsule = colliderObject.GetComponent<CapsuleCollider>();
        if (capsule != null)
        {
            // Adjust the length of the collider to match the line
            float lineLength = Vector3.Distance(startPoint, endPoint);
            capsule.height = lineLength + capsule.radius; // Adjust length to cover entire line

            // Align the collider with the line
            colliderObject.transform.LookAt(startPoint); // Point towards one end of the line
            colliderObject.transform.Rotate(90f, 0f, 0f); // Tilt to align with line direction
        }
    }
}


// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;
// using UnityEngine.InputSystem;

// public class spawnLine : MonoBehaviour
// {
//     public Vector3 startPoint;
//     public Vector3 endPoint;
//     private LineRenderer lineRenderer;


//     void Start()
//     {
//         lineRenderer = gameObject.AddComponent<LineRenderer>();
//         lineRenderer.material = new Material(Shader.Find("Standard"));
//         lineRenderer.startWidth = 0.01f;
//         lineRenderer.endWidth = 0.01f;
//         lineRenderer.positionCount = 2;

//         // Initial setup
//         UpdateLinePositions();
//     }

//     void Update()
//     {
//         UpdateLinePositions();
//     }

//     private void UpdateLinePositions()
//     {
//         if (startPoint != null && endPoint != null)
//         {
//             lineRenderer.SetPosition(0, startPoint);
//             lineRenderer.SetPosition(1, endPoint);
//         }
//     }
// }
