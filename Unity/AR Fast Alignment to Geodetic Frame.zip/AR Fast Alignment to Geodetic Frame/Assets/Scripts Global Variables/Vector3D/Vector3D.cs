[System.Serializable]
public class Vector3D
{
    public double x, y, z;

    public Vector3D(double lat, double lon, double alt)
    {
        x = lat;
        y = lon;
        z = alt;
    }
}