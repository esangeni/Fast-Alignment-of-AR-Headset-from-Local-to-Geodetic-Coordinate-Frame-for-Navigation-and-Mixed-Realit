using System;
using UnityEngine;

public static class CoordsConverter
{
#region CONSTANTS
    private const double DEGREES_TO_RADIANS = Math.PI / 180.0;
    private const double RADIANS_TO_DEGREES = 180.0 / Math.PI;
    private const double WGS84_A = 6378137.0;                                               //Semi-major axis of the Earth
    private const double WGS84_IF = 298.257223563;                                          //Inverse flattening of the Earth
    private const double WGS84_F = 1.0 / WGS84_IF;                                          //The flattening of the Earth
    private static readonly double WGS84_E = Math.Sqrt(2.0 * WGS84_F - WGS84_F * WGS84_F);  //Eccentricity of the Earth
    private static readonly double b = WGS84_A * (1 - WGS84_F);                             // Semi-minor axis
    private static readonly double ePrimeSquared = (WGS84_A * WGS84_A - b * b) / (b * b);
#endregion

    // ---------------------------------------------------------------------------------------------
    // --------------------------------------- LLA to Unity ----------------------------------------
    // ---------------------------------------------------------------------------------------------

    public static Vector3D ConvertLLAToECEF(Vector3D lla)
    {
        double lat = lla.x * DEGREES_TO_RADIANS;
        double lon = lla.y * DEGREES_TO_RADIANS;
        double alt = lla.z;

        double clat = Math.Cos(lat);
        double slat = Math.Sin(lat);
        double clon = Math.Cos(lon);
        double slon = Math.Sin(lon);

        double N = WGS84_A / Math.Sqrt(1.0 - WGS84_E * WGS84_E * slat * slat);

        double x = (N + alt) * clat * clon;
        double y = (N + alt) * clat * slon;
        double z = (N * (1.0 - WGS84_E * WGS84_E) + alt) * slat;

        return new Vector3D(x, y, z);
    }

    public static Vector3D ConvertECEFToENU(Vector3D initLLA, Vector3D initECEF, Vector3D targetECEF)
    {
        double lat = initLLA.x * DEGREES_TO_RADIANS;
        double lon = initLLA.y * DEGREES_TO_RADIANS;

        double dx = targetECEF.x - initECEF.x;
        double dy = targetECEF.y - initECEF.y;
        double dz = targetECEF.z - initECEF.z;

        double clat = Math.Cos(lat);
        double slat = Math.Sin(lat);
        double clon = Math.Cos(lon);
        double slon = Math.Sin(lon);

        double e = -slon * dx + clon * dy;
        double n = -slat * clon * dx - slat * slon * dy + clat * dz;
        double u = clat * clon * dx + clat * slon * dy + slat * dz;

        return new Vector3D(e, n, u);
    }

    public static Vector3D ConvertENUtoUnityEUN(Vector3D enu)
    {
        // Considering Unity's coordinate system (Left-Handed): Y is up, Z is forward.
        // ENU: East, North, Up - Maps to - X, Z, Y in Unity's system
        double x = enu.x;     // East goes directly to X
        double y = enu.z;     // Up goes to Y
        double z = enu.y;     // North goes to Z, which is Unity's forward

        return new Vector3D(-x, y, -z);
    }

    // ---------------------------------------------------------------------------------------------
    // --------------------------------------- Unity to LLA ----------------------------------------
    // ---------------------------------------------------------------------------------------------


    public static Vector3D ConvertECEFoLLA(Vector3D ecef)
    {
        double X = ecef.x;
        double Y = ecef.y;
        double Z = ecef.z;

        double p = Math.Sqrt(X * X + Y * Y);
        double theta = Math.Atan2(Z * WGS84_A, p * b);
        double eSquared = WGS84_E * WGS84_E;
        double ePrimeSquared = (WGS84_A * WGS84_A - b * b) / (b * b);

        double sinTheta = Math.Sin(theta);
        double cosTheta = Math.Cos(theta);

        double num = Z + ePrimeSquared * b * Math.Pow(sinTheta, 3);
        double denom = p - eSquared * WGS84_A * Math.Pow(cosTheta, 3);

        double lat = Math.Atan2(num, denom);
        double lon = Math.Atan2(Y, X);

        // Using an approximate formula for altitude
        double sinLat = Math.Sin(lat);
        double N = WGS84_A / Math.Sqrt(1 - eSquared * sinLat * sinLat);
        double alt = p / Math.Cos(lat) - N;

        // Converting radians to degrees for latitude and longitude
        lat *= RADIANS_TO_DEGREES;
        lon *= RADIANS_TO_DEGREES;

        // Ensure longitude is between -180 and 180 degrees
        if (lon > 180) lon -= 360;

        return new Vector3D(lat, lon, alt);
    }

    public static Vector3D ConvertENUToECEF(Vector3D initLLA, Vector3D enu, Vector3D initECEF)
    {
        double lat = initLLA.x * DEGREES_TO_RADIANS;
        double lon = initLLA.y * DEGREES_TO_RADIANS;

        double e = enu.x;
        double n = enu.y;
        double u = enu.z;

        double clat = Math.Cos(lat);
        double slat = Math.Sin(lat);
        double clon = Math.Cos(lon);
        double slon = Math.Sin(lon);

        // Define the transformation matrix from ENU to ECEF as per your provided formula: https://gssc.esa.int/navipedia/index.php/Transformations_between_ECEF_and_ENU_coordinates
        double[,] rotMat = new double[3, 3] {
            { -slon, -clon * slat, clat * clon },
            { clon, -slon * slat, slon * clat },
            { 0, clat, slat }
        };

        // Perform the matrix-vector multiplication
        Vector3D ecefDelta = new Vector3D(
            (float)(rotMat[0, 0] * e + rotMat[0, 1] * n + rotMat[0, 2] * u),
            (float)(rotMat[1, 0] * e + rotMat[1, 1] * n + rotMat[1, 2] * u),
            (float)(rotMat[2, 0] * e + rotMat[2, 1] * n + rotMat[2, 2] * u)
        );

        // Add the delta to the initial ECEF position to get the final ECEF coordinates
        Vector3D finalECEF = new Vector3D(
            initECEF.x + ecefDelta.x,
            initECEF.y + ecefDelta.y,
            initECEF.z + ecefDelta.z
        );

        return finalECEF;
    }

    public static Vector3D ConvertUnityEUNtoENU(Vector3D unityEUN)
    {
        // ENU to EUN:
        //      E->x, N->y, U->z
        //      E->-x, U->z, N->-y

        // EUN to ENU:
        //      E->x, U->y, N->z
        //      E->-x, N->z, U->-y

        // Unity EUN (-X, Y, -Z) to ENU (X, Y, Z)
        double e = -unityEUN.x; // Undo negation to get East
        double n = unityEUN.z; // Undo negation to get North
        double u = -unityEUN.y; // Up remains the same

        return new Vector3D(e, n, u);
    }


    //-------------

    public static Vector3D ConvertBodyToENU(Vector3D bodyCoordinates)
    {
        Quaternion q_BodyToTrueNorth = BodyToENUInitialRoationSingleton.Instance.q_TagToTrueNorth * BodyToENUInitialRoationSingleton.Instance.q_BodyToTag;
        
        Vector3 xyzBodyCoordinatesVector3 = new Vector3((float)bodyCoordinates.x, (float)bodyCoordinates.y, (float)bodyCoordinates.z);
        Vector3 rotatedPositionVector = q_BodyToTrueNorth * xyzBodyCoordinatesVector3;
        
        double e = rotatedPositionVector.x; // Undo negation to get East
        double n = rotatedPositionVector.z; // Undo negation to get North
        double u = rotatedPositionVector.y; // Up remains the same

        return new Vector3D(e, n, u);
    }

    // public static Vector3D ConvertENUToBody(Vector3D enuCoordinates)
    // {
    //     Debug.Log("q_TagToTrueNorth: " + BodyToENUInitialRoationSingleton.Instance.q_TagToTrueNorth.ToString());
    //     Debug.Log("q_BodyToTag: " + BodyToENUInitialRoationSingleton.Instance.q_BodyToTag.ToString());
    //     Debug.Log("q_TagToTrueNorth euler y: " + BodyToENUInitialRoationSingleton.Instance.q_TagToTrueNorth.eulerAngles.y.ToString());
    //     Debug.Log("q_BodyToTag euler x: " + BodyToENUInitialRoationSingleton.Instance.q_BodyToTag.eulerAngles.x.ToString());
    //     Debug.Log("q_BodyToTag euler y: " + BodyToENUInitialRoationSingleton.Instance.q_BodyToTag.eulerAngles.y.ToString());
    //     Debug.Log("q_BodyToTag euler z: " + BodyToENUInitialRoationSingleton.Instance.q_BodyToTag.eulerAngles.z.ToString());
    //     // Quaternion q_BodyToTrueNorth = BodyToENUInitialRoationSingleton.Instance.q_TagToTrueNorth * BodyToENUInitialRoationSingleton.Instance.q_BodyToTag;


    //     // Quaternion q_BodyToTrueNorth = Quaternion.Euler(
    //     //     new Vector3(0, BodyToENUInitialRoationSingleton.Instance.q_TagToTrueNorth.eulerAngles.y, 0) + //(0,-48,0)
    //     //     new Vector3(0, -BodyToENUInitialRoationSingleton.Instance.q_BodyToTag.eulerAngles.y,      0));

    //     Quaternion qRotation = BodyToENUInitialRoationSingleton.Instance.q_BodyToTag;
    //     Quaternion q_BodyToTrueNorth = qRotation;


    //     Debug.Log("q_BodyToTrueNorth: " + q_BodyToTrueNorth.eulerAngles.ToString());

    //     Quaternion q_TrueNorthToBody = Quaternion.Inverse(q_BodyToTrueNorth);
    //     Debug.Log("q_TrueNorthToBody: " + q_TrueNorthToBody.eulerAngles.ToString());

    //     // Convert the ENU coordinates to Vector3 for the operation
    //     Vector3 enuCoordinatesVector3 = new Vector3((float)enuCoordinates.x, (float)enuCoordinates.y, (float)enuCoordinates.z);
    //     enuCoordinatesVector3.Normalize();
    //     Vector3 bodyPositionVector = q_BodyToTrueNorth * enuCoordinatesVector3;

    //     // Construct a Vector3D from the result, converting back to double precision if necessary
    //     Vector3D bodyCoordinates = new Vector3D(bodyPositionVector.x, bodyPositionVector.y, bodyPositionVector.z);
    //     Debug.Log("bodyCoordinates: " + bodyCoordinates.x.ToString() + ", " + bodyCoordinates.y.ToString() + ", " + bodyCoordinates.z.ToString());
    //     return bodyCoordinates;
    // }

    public static Vector3D ConvertENUToBody(Vector3D enuCoordinates)
    {
        Vector3D llaTarget = TargetPosSingleton.Instance.LLAData; // Target position in Lat, Lon, Alt
        Vector3D llaPlayer = PlayerPosSingleton.Instance.InitLLAData; // Player's initial position in Lat, Lon, Alt
        Debug.Log("- llaTarget: " + llaTarget.x.ToString() + ", " + llaTarget.y.ToString() + ", " + llaTarget.z.ToString());
        Debug.Log("- llaPlayer: " + llaPlayer.x.ToString() + ", " + llaPlayer.y.ToString() + ", " + llaPlayer.z.ToString());
        // Calculate bearing from player to target
        double northTargetBearing = CalculateBearing(llaPlayer.x, llaPlayer.y, llaTarget.x, llaTarget.y);
        Debug.Log("- northTargetBearing: " + northTargetBearing.ToString());
        Debug.Log("- q_TagToTrueNorth x: " + BodyToENUInitialRoationSingleton.Instance.q_TagToTrueNorth.eulerAngles.x.ToString());
        Debug.Log("- q_TagToTrueNorth y: " + BodyToENUInitialRoationSingleton.Instance.q_TagToTrueNorth.eulerAngles.y.ToString());
        Debug.Log("- q_TagToTrueNorth z: " + BodyToENUInitialRoationSingleton.Instance.q_TagToTrueNorth.eulerAngles.z.ToString());
        Debug.Log("- q_BodyToTag x: " + BodyToENUInitialRoationSingleton.Instance.q_BodyToTag.eulerAngles.x.ToString());
        Debug.Log("- q_BodyToTag y: " + BodyToENUInitialRoationSingleton.Instance.q_BodyToTag.eulerAngles.y.ToString());
        Debug.Log("- q_BodyToTag z: " + BodyToENUInitialRoationSingleton.Instance.q_BodyToTag.eulerAngles.z.ToString());

        // Calculate delta angle, incorporating the True North offset from Tag
        float delta = (float)northTargetBearing + (360 - BodyToENUInitialRoationSingleton.Instance.q_BodyToTag.eulerAngles.y);
        Debug.Log("- Delta: " + delta.ToString());

        // Use quaternion to represent the rotation by delta angle around the Up axis
        Quaternion rotationDelta = Quaternion.Euler(0, delta, 0);

        // Convert the ENU coordinates to Unity's Vector3
        Vector3 enuCoordinatesVector3 = new Vector3((float)enuCoordinates.x, (float)enuCoordinates.y, (float)enuCoordinates.z);
        
        // Apply the rotation
        Vector3 bodyPositionVector = rotationDelta * enuCoordinatesVector3;

        // Logging the result (Ensure 'bodyPositionVector' is what you intended to log)
        Debug.Log("- bodyCoordinates: " + bodyPositionVector.x.ToString() + ", " + bodyPositionVector.y.ToString() + ", " + bodyPositionVector.z.ToString());

        // Returning the corrected coordinates (Need to make sure Vector3D can be constructed this way)
        Vector3D bodyCoordinates = new Vector3D(bodyPositionVector.x, bodyPositionVector.y, bodyPositionVector.z);
        return bodyCoordinates;
    }


    public static double CalculateBearing(double lat1, double lon1, double lat2, double lon2)
    {
        // Convert latitude and longitude values from degrees to radians
        var lat1Rad = DegreesToRadians(lat1);
        var lon1Rad = DegreesToRadians(lon1);
        var lat2Rad = DegreesToRadians(lat2);
        var lon2Rad = DegreesToRadians(lon2);

        // Calculate differences
        var deltaLonRad = lon2Rad - lon1Rad;

        // Calculate bearing
        var y = Math.Sin(deltaLonRad) * Math.Cos(lat2Rad);
        var x = Math.Cos(lat1Rad) * Math.Sin(lat2Rad) -
                Math.Sin(lat1Rad) * Math.Cos(lat2Rad) * Math.Cos(deltaLonRad);
        var bearingRad = Math.Atan2(y, x);

        // Convert from radians to degrees
        var bearingDeg = RadiansToDegrees(bearingRad);

        // Normalize the result to be within the range [0, 360)
        var bearingNormalized = (bearingDeg + 360) % 360;

        return bearingNormalized;
    }


    private static double DegreesToRadians(double degrees)
    {
        return degrees * Math.PI / 180.0;
    }

    private static double RadiansToDegrees(double radians)
    {
        return radians * 180.0 / Math.PI;
    }
}