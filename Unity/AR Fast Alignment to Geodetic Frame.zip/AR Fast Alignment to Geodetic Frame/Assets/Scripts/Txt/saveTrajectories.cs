using System;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;
using UnityEngine.Android;

public class SaveData : MonoBehaviour
{
    # region private members
    private MagicLeapInputs _magicLeapInputs;
    private MagicLeapInputs.ControllerActions _controllerActions;
    private string filePath;
    # endregion

    # region public members
    public string fileName;
    # endregion
    

    void Start()
    {
        if (!Permission.HasUserAuthorizedPermission(Permission.ExternalStorageWrite))
        {
            Permission.RequestUserPermission(Permission.ExternalStorageWrite);
        }

        // File Name:
        DateTime now = DateTime.Now;
        string formattedDateTime = now.ToString("yyyyMMdd_HHmmss"); // Adjust format as needed (e.g., "yyyy-MM-dd_HH-mm-ss")
        // fileName = $"exp_{formattedDateTime}.txt";

        // Get the file path on the ML2 device
        filePath = Path.Combine(Application.persistentDataPath, fileName);
    }

    // Update is called once per frame
    void FixedUpdate(){

        string utime_txt = Time.deltaTime.ToString() + ", ";   // timestamp
        string aligmentOffset_txt = AligmentRotationSingleton.Instance.aligmentRotOffset.ToString() + ", ";
        string playerXYZ_txt = PlayerPosSingleton.Instance.CurrXYZData.x.ToString() + ", " + PlayerPosSingleton.Instance.CurrXYZData.y.ToString() + ", " + PlayerPosSingleton.Instance.CurrXYZData.z.ToString() + ", ";
        string playerXYZAlign_txt = PlayerPosSingleton.Instance.CurrXYZAlignData.x.ToString() + ", " + PlayerPosSingleton.Instance.CurrXYZAlignData.y.ToString() + ", " + PlayerPosSingleton.Instance.CurrXYZAlignData.z.ToString() + ", ";
        string playerENU_txt = PlayerPosSingleton.Instance.CurrENUData.x.ToString() + ", " + PlayerPosSingleton.Instance.CurrENUData.y.ToString() + ", " + PlayerPosSingleton.Instance.CurrENUData.z.ToString() + ", ";
        string playerENUAlign_txt = PlayerPosSingleton.Instance.CurrENUAlignData.x.ToString() + ", " + PlayerPosSingleton.Instance.CurrENUAlignData.y.ToString() + ", " + PlayerPosSingleton.Instance.CurrENUAlignData.z.ToString() + ", ";
        string playerECEF_txt = PlayerPosSingleton.Instance.CurrECEFData.x.ToString() + ", " + PlayerPosSingleton.Instance.CurrECEFData.y.ToString() + ", " + PlayerPosSingleton.Instance.CurrECEFData.z.ToString() + ", ";
        string playerECEFAlign_txt = PlayerPosSingleton.Instance.CurrECEFAlignData.x.ToString() + ", " + PlayerPosSingleton.Instance.CurrECEFAlignData.y.ToString() + ", " + PlayerPosSingleton.Instance.CurrECEFAlignData.z.ToString() + ", ";
        string playerLLA_txt = PlayerPosSingleton.Instance.CurrLLAData.x.ToString() + ", " + PlayerPosSingleton.Instance.CurrLLAData.y.ToString() + ", " + PlayerPosSingleton.Instance.CurrLLAData.z.ToString() + ", ";    // Firefighter LLA Position
        string playerLLAAlign_txt = PlayerPosSingleton.Instance.CurrLLAAlignData.x.ToString() + ", " + PlayerPosSingleton.Instance.CurrLLAAlignData.y.ToString() + ", " + PlayerPosSingleton.Instance.CurrLLAAlignData.z.ToString();
        // string LLA_obj_txt = ObjectPosSingleton.Instance.CurrLLAData.ToString();         // Object LLA Position

        string mssg2store = utime_txt + aligmentOffset_txt + playerXYZ_txt + playerXYZAlign_txt + playerENU_txt + playerENUAlign_txt + playerECEF_txt + playerECEFAlign_txt + playerLLA_txt + playerLLAAlign_txt + Environment.NewLine;

        File.AppendAllText(filePath, mssg2store);
        // File.WriteAllBytes(filePath, mssg2store);
    }
}