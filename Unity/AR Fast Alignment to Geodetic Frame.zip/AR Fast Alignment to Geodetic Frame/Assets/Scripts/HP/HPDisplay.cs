//                 HPDisplay SCRIPT:
//-------------------------------------------------------------
// This file reads the data from the Marker Tracking using 
// CV to determine position of the hand respect to the headset.
// Also, it reads the UDP data from the HP (ESP32) wich includes
// {lidar, button states and GPS}.
// 
// This file displays the laser pointer when the switch button is
// pressed and it computes the object position.
//-------------------------------------------------------------

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HPDisplay : MonoBehaviour
{   
    # region Private Scripts Binds:
    private UDPServer udpServer;
    private HPPositionAprilTag hpPositionAprilTag;
    # endregion

    #region  Private Game Objects:
    private GameObject HPlatform;
    private LineRenderer laserPointer;
    # endregion

    # region Private Variables:
    private float lineWidthSetting = 0.01f;
    private int countFirstObjectTracked = 0;
    // private bool triggerIsPressed = true;
    // private float lidarDist = 10;
    # endregion

    # region Public Variables:
    public int seenHP;
    public Vector3 R_object;
    public Vector3 R_hp;
    public Quaternion q_hp;
    public float lidarDist;
    public bool btn_1_IsPressed = false;
    public bool btn_2_IsPressed = false;
    public bool btn_3_IsPressed = false;
    public bool firstObjectTracked = false;
    # endregion

    // Start is called before the first frame update
    void Start()
    {
        // Get HP Object:
        HPlatform = GameObject.Find("Handheld Platform");
        
        // Get Scripts Dependencies:
        udpServer = FindObjectOfType<UDPServer>();
        hpPositionAprilTag = FindObjectOfType<HPPositionAprilTag>();

        // Laser Pointer to target objects:
        laserPointer = GameObject.Find("Laser Pointer").GetComponent<LineRenderer>();
        laserPointer.startWidth = lineWidthSetting;
        laserPointer.endWidth   = lineWidthSetting;
        laserPointer.positionCount = 0;
        laserPointer.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {
        seenHP = hpPositionAprilTag.updateHPAligment;   // see state if we see the HP

        if(udpServer.messageReceived)
        {
            if (udpServer.button_1 == 1)
            {
                btn_1_IsPressed = true;
                countFirstObjectTracked += 1;
            }
                
            if (udpServer.button_2 == 0)
                btn_2_IsPressed = true;
            if (udpServer.button_3 == 0)
                btn_3_IsPressed = true;
        }
        else
        {
            btn_1_IsPressed = false;
            btn_2_IsPressed = false;
            btn_3_IsPressed = false;
        }
        if(countFirstObjectTracked >= 1)
           firstObjectTracked = true; 

        if(hpPositionAprilTag.updateHPAligment == 1)
        {
            R_hp = new Vector3((float)HPPosSingleton.Instance.CurrXYZData.x, (float)HPPosSingleton.Instance.CurrXYZData.y, (float)HPPosSingleton.Instance.CurrXYZData.z);
            q_hp = Quaternion.Euler(HPPosSingleton.Instance.CurrRollPitchYawData);

            // Set Handheld Platform Position:
            HPlatform.transform.position = R_hp;
            HPlatform.transform.rotation = q_hp;

            print(udpServer.button_1);

            if(btn_1_IsPressed) // triggerIsPressed -  btn_1_IsPressed
            { 
                lidarDist = udpServer.lidarDist / 100; // distance received in [cm] to [m]            udpServer.lidarDist / 100
                
                // Compute initial distance pointer
                Quaternion q = q_hp*Quaternion.Euler(new Vector3(-15.51f, 0, 0)); // add 15.51 deg between QR and LiDAR
                q.Normalize();
                Vector3 R_initLine = ObjectPosition(R_hp, q, 0.069f);

                // Compute final distance of pointer
                R_object = ObjectPosition(R_initLine, q, lidarDist);


                // UPDATE VALUES OBJECT POSITION:
                // Read ML head position:
                ObjectPosSingleton.Instance.SetCurrXYZData(R_object.x, R_object.y, R_object.z);
                Debug.Log($"Curr player x: {ObjectPosSingleton.Instance.CurrXYZData.x}, y: {ObjectPosSingleton.Instance.CurrXYZData.y}, z: {ObjectPosSingleton.Instance.CurrXYZData.z}");
                
                // Read misalignment rotation offset and apply it
                int misalignmentRotationOffset = AligmentRotationSingleton.Instance.aligmentRotOffset;
                // Quaternion misalignmentRotation = Quaternion.Euler(180, -90+misalignmentRotationOffset, 180);
                Quaternion misalignmentRotation = Quaternion.Euler(0, -misalignmentRotationOffset*2-90, 180);

                Vector3 CurrXYZDataRot_v3 = new Vector3((float)ObjectPosSingleton.Instance.CurrXYZData.x, (float)ObjectPosSingleton.Instance.CurrXYZData.y, (float)ObjectPosSingleton.Instance.CurrXYZData.z);
                CurrXYZDataRot_v3 = misalignmentRotation * CurrXYZDataRot_v3;
                Vector3D CurrXYZDataRot_v3d = new Vector3D((double)CurrXYZDataRot_v3.x, (double)CurrXYZDataRot_v3.y, (double)CurrXYZDataRot_v3.z);
                
                // Adapt Current ML Unity's frame frame to ENU:
                // var objectCurrENU = CoordsConverter.ConvertUnityEUNtoENU(ObjectPosSingleton.Instance.CurrXYZData);
                var objectCurrENU = CoordsConverter.ConvertUnityEUNtoENU(CurrXYZDataRot_v3d);
                ObjectPosSingleton.Instance.SetCurrENUData(objectCurrENU.x, objectCurrENU.y, objectCurrENU.z);
                // Convert ENU to ECEF frame with center point initial fighter position:
                var objectCurrECEF = CoordsConverter.ConvertENUToECEF(PlayerPosSingleton.Instance.InitLLAData, ObjectPosSingleton.Instance.CurrENUData, PlayerPosSingleton.Instance.InitECEFData);
                ObjectPosSingleton.Instance.SetCurrECEFData(objectCurrECEF.x, objectCurrECEF.y, objectCurrECEF.z);
                // Convert ECEF to LLA frame:
                var objectLLAENU = CoordsConverter.ConvertECEFoLLA(ObjectPosSingleton.Instance.CurrECEFData);
                ObjectPosSingleton.Instance.SetCurrLLAData(objectLLAENU.x, objectLLAENU.y, objectLLAENU.z);


                // Laser Settings:
                laserPointer.positionCount = 2;
                laserPointer.SetPosition(0, R_initLine);
                print("Laser Pointer pos 0: " + R_hp);
                laserPointer.SetPosition(1, new Vector3(R_object.x, R_object.y, R_object.z));
                print("Object pos: " + R_object);
                print("Object LLA: " + ObjectPosSingleton.Instance.CurrLLAData.x.ToString() + "[deg], " + ObjectPosSingleton.Instance.CurrLLAData.y.ToString() + "[deg], " + ObjectPosSingleton.Instance.CurrLLAData.z.ToString() + "[m]");

                laserPointer.startColor = Color.white;
                laserPointer.endColor = Color.white;
                laserPointer.enabled = true;
            }
        }
        else 
        {
            laserPointer.enabled = false;
        }
    }

    private Vector3 ObjectPosition(Vector3 originPosition, Quaternion originRotation, float distance)
    {
        //1. Convert the quaternion representing the rotation of your oringin (hand) into a rotation matrix.
        //2. Create a Vector3 representing the direction from your origin (hand) to the final position (object).
        //3. Scale the direction vector by the distance to the object to obtain the offset vectro from your hand to the object.
        //4. Add the offset vectro to the postition of your hand to obtain the position of the object.

        Matrix4x4 rotationMatrix = Quaternion2DCM(originRotation);
        Vector4 product = rotationMatrix * new Vector4(0,0,1,0); // direction axis-z (forward)
        Vector3 direction = new Vector3(product.x, -product.y, product.z);
        Vector3 offset = distance * direction;
        Vector3 objectPosition = originPosition + offset;
        return objectPosition;
    }

    private static Matrix4x4 Quaternion2DCM(Quaternion quaternion)
    {
        // This function converts a quaternion to a directional cosine matrix
        Matrix4x4 rotationMatrix = new Matrix4x4();

        // First, calculate some intermediate values
        float x2 = quaternion.x * quaternion.x;
        float y2 = quaternion.y * quaternion.y;
        float z2 = quaternion.z * quaternion.z;
        float xy = quaternion.x * quaternion.y;
        float xz = quaternion.x * quaternion.z;
        float yz = quaternion.y * quaternion.z;
        float wx = quaternion.w * quaternion.x;
        float wy = quaternion.w * quaternion.y;
        float wz = quaternion.w * quaternion.z;

        // Then, populate the rotation matrix
        rotationMatrix.m00 = 1 - 2 * (y2 + z2);
        rotationMatrix.m01 = 2 * (xy - wz);
        rotationMatrix.m02 = 2 * (xz + wy);
        rotationMatrix.m03 = 0;

        rotationMatrix.m10 = 2 * (xy + wz);
        rotationMatrix.m11 = 1 - 2 * (x2 + z2);
        rotationMatrix.m12 = 2 * (yz - wx);
        rotationMatrix.m13 = 0;

        rotationMatrix.m20 = 2 * (xz - wy);
        rotationMatrix.m21 = 2 * (yz + wx);
        rotationMatrix.m22 = 1 - 2 * (x2 + y2);
        rotationMatrix.m23 = 0;

        rotationMatrix.m30 = 0;
        rotationMatrix.m31 = 0;
        rotationMatrix.m31 = 0;
        rotationMatrix.m33 = 1;

        return rotationMatrix;
    }
}
