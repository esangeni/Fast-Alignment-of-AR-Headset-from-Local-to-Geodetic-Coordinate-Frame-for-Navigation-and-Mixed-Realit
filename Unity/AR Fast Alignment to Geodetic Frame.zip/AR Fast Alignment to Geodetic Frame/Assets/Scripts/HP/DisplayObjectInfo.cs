using TMPro;
using UnityEngine;
using System.Collections.Generic;

public class DisplayObjectInfo : MonoBehaviour
{
    private HPDisplay hp;
    public Material objectMaterial;     // Reference to the material
    public TextMeshProUGUI textMeshPro; // Text mesh pro

    #region private members
    private bool clearAll = false;
    private string displayText;
    private List<float> distances = new List<float>();
    private List<Vector3> positions = new List<Vector3>();
    private List<Quaternion> rotations = new List<Quaternion>();
    private List<GameObject> spheres = new List<GameObject>(); // List to store the spheres
    private Dictionary<Vector3, TextMeshPro> distanceTexts = new Dictionary<Vector3, TextMeshPro>(); // Dictionary to store the distance texts
    #endregion

    private void Start()
    {
        hp = FindObjectOfType<HPDisplay>();
    }

    private void LateUpdate()
    {
        if (hp.firstObjectTracked)
        {
            // While Trigger Pressed:

            string R_object_str = hp.R_object.ToString("F2");
            string objctDist_str = Vector3.Distance(hp.R_object, new Vector3((float)PlayerPosSingleton.Instance.CurrXYZData.x, (float)PlayerPosSingleton.Instance.CurrXYZData.y, (float)PlayerPosSingleton.Instance.CurrXYZData.z)).ToString("F2");

            textMeshPro.transform.position = hp.R_object + new Vector3(0, 0.25f, 0);
            Quaternion q = hp.q_hp*Quaternion.Euler(new Vector3(180,180,0));
            textMeshPro.transform.rotation = Quaternion.Euler(new Vector3(q.eulerAngles.x,q.eulerAngles.y,0));

            displayText = "(" + ObjectPosSingleton.Instance.CurrLLAData.x.ToString("F6") + ", " + ObjectPosSingleton.Instance.CurrLLAData.y.ToString("F6") + ", " + ((ObjectPosSingleton.Instance.CurrLLAData.z+1.3f)).ToString("F1") + ")\n" + 
                          "Obj Dist: " + objctDist_str + "[m]";
            //"Obj Pos: " + R_object_str + "[m] \n" +

            if(hp.btn_1_IsPressed)
                clearAll = false;
            if(clearAll)
                displayText = "";

            // When Trigger is realsed:
            if (!hp.btn_1_IsPressed && !clearAll)
            {
                displayText = "";
                
                positions.Add(hp.R_object);
                distances.Add(Vector3.Distance(hp.R_object, hp.R_hp));
                Quaternion qq = hp.q_hp*Quaternion.Euler(new Vector3(180,180,0));
                rotations.Add(Quaternion.Euler(new Vector3(qq.eulerAngles.x, qq.eulerAngles.y, 0)));

                // Create a new sphere object
                GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                sphere.transform.localScale = new Vector3(1f, 1f, 1f) * 0.075f;
                sphere.GetComponent<Renderer>().material = objectMaterial;
                sphere.transform.position = hp.R_object;
                spheres.Add(sphere); // Add the sphere to the list

                if (!distanceTexts.ContainsKey(hp.R_object))
                {
                    GameObject textObject = new GameObject("DistanceText");
                    textObject.transform.position = hp.R_object + new Vector3(0f, 0.5f, 0f);
                    TextMeshPro distanceText = textObject.AddComponent<TextMeshPro>();
                    distanceText.text = "(" + ObjectPosSingleton.Instance.CurrLLAData.x.ToString("F6") + ", " + ObjectPosSingleton.Instance.CurrLLAData.y.ToString("F6") + ", " + ((ObjectPosSingleton.Instance.CurrLLAData.z+1.3f)).ToString("F1") + ")";
                    distanceText.alignment = TextAlignmentOptions.Center;
                    distanceText.fontSize = 0.75f;
                    distanceText.color = Color.white;
                    distanceTexts.Add(hp.R_object, distanceText); // Add the text mesh to the dictionary
                }
            }

            // Update the position and text for existing spheres
            for (int i = 0; i < spheres.Count; i++)
            {
                spheres[i].transform.position = positions[i];

                // distanceTexts[positions[i]].text = "Dist to obj: " + Vector3.Distance(new Vector3(positions[i].x, 0, positions[i].z), new Vector3((float)PlayerPosSingleton.Instance.CurrXYZData.x, 0, (float)PlayerPosSingleton.Instance.CurrXYZData.z)).ToString("F2") + "[m]";
                distanceTexts[positions[i]].transform.position = positions[i] + new Vector3(0, 0.25f, 0);
                distanceTexts[positions[i]].transform.rotation = rotations[i];
            }

            if (hp.btn_2_IsPressed)
            {
                clearAll = true;

                // Destroy all spheres
                foreach (GameObject sphere in spheres)
                {
                    Destroy(sphere);
                }
                spheres.Clear();

                // Destroy all text objects
                foreach (TextMeshPro distanceText in distanceTexts.Values)
                {
                    Destroy(distanceText.gameObject);
                }
                distanceTexts.Clear();

                // Clear lists and dictionaries
                distances.Clear();
                positions.Clear();
                rotations.Clear();
            }

            textMeshPro.text = displayText;
        }
    }
}