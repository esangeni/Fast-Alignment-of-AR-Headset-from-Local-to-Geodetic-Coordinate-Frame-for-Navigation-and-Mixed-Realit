using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class CanvasControlBUG2 : MonoBehaviour
{
    // Define references to the TextMeshPro components
    private TextMeshProUGUI currentAltitudeText;
    private TextMeshProUGUI targetAltitudeText;
    private RawImage objectiveIconImage;

    // Start is called before the first frame update
    void Start()
    {
        // Find and assign the TextMeshProUGUI components
        currentAltitudeText = GameObject.Find("CurrentAltitudeText").GetComponent<TextMeshProUGUI>();
        targetAltitudeText = GameObject.Find("TargetAltitudeText").GetComponent<TextMeshProUGUI>();
        
        // Just a check to make sure they're found, you can remove these lines
        if(currentAltitudeText != null) Debug.Log("Found CurrentAltitudeText");
        if(targetAltitudeText != null) Debug.Log("Found TargetAltitudeText");
    }

    // Update is called once per frame
    void Update()
    {
        if(currentAltitudeText != null)
            currentAltitudeText.text = "Current Alt: " + PlayerPosSingleton.Instance.CurrXYZData.y.ToString("F1") + " [m]";
        if(targetAltitudeText != null)
            targetAltitudeText.text = "Target Alt: " + TargetPosSingleton.Instance.XYZData.y.ToString("F1") + " [m]";
    }
}
