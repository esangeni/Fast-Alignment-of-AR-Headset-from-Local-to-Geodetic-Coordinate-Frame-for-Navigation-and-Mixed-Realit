using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BUG2 : MonoBehaviour
{
    [Header("BUG Path Line Render:")]
    public LineRenderer bugLine;
    [SerializeField] private double lineWidthSetting = 0.25;
    [SerializeField] private Vector3D targetXYZ;
    
    private GameObject targetPointer;
    [Range(0, 360)] public int aligmentOffset;
    public Slider aligmentSlider;
    [Range(0, 2), SerializeField] private float personHeight; // The offset is then /100 so and offset of 20 = 0.2
    public TextMeshProUGUI sliderValueTxt;
    void Start()
    {
        // BUG Line settings:
        SetupBugLine();

        // Target final pointer:
        targetPointer = GameObject.Find("3D Pointer");
        targetPointer.SetActive(false);

        // Initialize the player position on the sigleton in unity frame:
        PlayerPosSingleton.Instance.SetInitXYZData(PlayerPosSingleton.Instance.CurrXYZData.x, PlayerPosSingleton.Instance.CurrXYZData.y, PlayerPosSingleton.Instance.CurrXYZData.z);
    }

    void Update()
    {
        // Update aligmentOffset with the slider value
        if (aligmentSlider != null)
        {
            aligmentSlider.value = aligmentOffset;
            AligmentRotationSingleton.Instance.SetAligRotOffset(aligmentOffset);

            if (sliderValueTxt != null)
            {
                sliderValueTxt.text = $"Angle Offset: {aligmentOffset:F1} [deg]";
            }
        }

        // 1 Convert LLA to ECEF frame:
        var targetECEF = CoordsConverter.ConvertLLAToECEF(TargetPosSingleton.Instance.LLAData);
        TargetPosSingleton.Instance.SetECEFData(targetECEF.x, targetECEF.y, targetECEF.z);

        // 2 Convert ECEF to ENU frame with center point initial fighter position:
        var targetENU = CoordsConverter.ConvertECEFToENU(PlayerPosSingleton.Instance.InitLLAData, PlayerPosSingleton.Instance.InitECEFData, TargetPosSingleton.Instance.ECEFData);
        TargetPosSingleton.Instance.SetENUData(targetENU.x, targetENU.y, targetENU.z);

        // 3 Adapt ENU frame to Unity's frame
        var targetEUN = CoordsConverter.ConvertENUtoUnityEUN(TargetPosSingleton.Instance.ENUData);
        TargetPosSingleton.Instance.SetXYZData(targetEUN.x, targetEUN.y, targetEUN.z);
        Vector3 targetXYZ_f = new Vector3((float)targetXYZ.x, (float)targetXYZ.y, (float)targetXYZ.z);
        
        // targetXYZ_f = Quaternion.Euler(0, AligmentRotationSingleton.Instance.aligmentRotOffset, 0) * targetXYZ_f;
        // targetXYZ = new Vector3D((double)targetXYZ_f.x, (double)targetXYZ_f.y, (double)targetXYZ_f.z);

        // AligmentRotationSingleton.Instance.SetAligRotOffset(aligmentOffset);
        targetXYZ_f = Quaternion.Euler(0, aligmentOffset, 0) * targetXYZ_f;
        targetXYZ = new Vector3D((double)targetXYZ_f.x, (double)targetXYZ_f.y, (double)targetXYZ_f.z);

        // 4. Draw the 3D m-line:
        DrawBUGPath(PlayerPosSingleton.Instance.InitXYZData, targetXYZ); //TargetPosSingleton.Instance.XYZData
        targetXYZ = TargetPosSingleton.Instance.XYZData;
    }

    void SetupBugLine()
    {
        bugLine.startWidth = (float)lineWidthSetting;
        bugLine.endWidth = (float)lineWidthSetting;
        bugLine.positionCount = 0;
        bugLine.enabled = false;
    }

    private void DrawBUGPath(Vector3D initVector, Vector3D finalVector)
    {
        bugLine.enabled = true;
        bugLine.positionCount = 2;
        bugLine.SetPosition(0, new Vector3((float)initVector.x, (float)initVector.y - personHeight, (float)initVector.z));
        bugLine.SetPosition(1, new Vector3((float)finalVector.x, (float)finalVector.y - personHeight, (float)finalVector.z));

        targetPointer.SetActive(true);
        targetPointer.transform.position = new Vector3((float)finalVector.x, (float)finalVector.y - personHeight + 0.25f, (float)finalVector.z);
    }
}